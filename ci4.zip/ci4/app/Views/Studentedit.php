<html>
    <head>
        <style>
        img{
            witdh:10%;
            height:10%;
        }
        table{
            width:100%;
        }
        tr,td{
            padding:8px;
            border:1px solid #ddd;
        }
    </style>
        </head>
        <body>
            <form method='post' action='<?php echo site_url('update'); ?>' enctype='multipart/form-data'>
            <input type='hidden' value='<?php echo $s['id']; ?>' name='id'>
                <label >name: <input type='text' name='name' value='<?php echo $s['name']; ?>' ></label><br>
                <label >email: <input type='email' name='email' value='<?php echo $s['email']; ?>' ></label><br>
                <label >file: <input type='file' name='file' value='<?php echo $s['file']; ?>'></label><br>
                <input type='submit'  value='update' ></label><br>
    </form>

    </body>
    </html>