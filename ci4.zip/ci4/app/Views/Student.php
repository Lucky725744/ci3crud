<html>
    <head>
        <style>
        img{
            width:10%;
            height:10%;
        }
        table{
            width:100%;
        }
        tr,td,th{
            padding:8px;
            border:1px solid #ddd;
        }
    </style>
        </head>
        <body>
            <form method='post' action='<?php echo site_url('store'); ?>' enctype='multipart/form-data'>
                <label >name: <input type='text' name='name' value='' ></label><br>
                <label >email: <input type='email' name='email' value='' ></label><br>
                <label >file: <input type='file' name='file' value='' ></label><br>
                <input type='submit' name='submit' value='submit' ></label><br>
    </form>

    <table>
        <tr><th>id</th><th>name</th><th>email</th><th>file</th><th>edit</th></tr>
        <?php foreach($student as $s){?>
            <tr>
                <td><?php echo $s['id']; ?></td>
                <td><?php echo $s['name']; ?></td>
                <td><?php echo $s['email']; ?></td>
                <td><image src='<?php echo site_url('uploads/') . $s['file']; ?>' alt='file'></td>
                <form method='post' action='<?php echo site_url('edit'); ?>' enctype='multipart/form-data'>
                <input type='hidden' value='<?php echo $s['id']; ?>' name='id'>
                 <td><input type='submit' name='edit' value='edit'></td>
        </form>
        </tr>
        <?php } ?>
    </table>
    </body>
    </html>