<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('student','StudentController::index');
$routes->post('store','StudentController::store');
$routes->post('edit','StudentController::edit');
$routes->post('update','StudentController::update');