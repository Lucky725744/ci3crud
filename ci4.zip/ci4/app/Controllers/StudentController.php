<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\StudentModel;
use CodeIgniter\HTTP\ResponseInterface;

class StudentController extends BaseController
{
    public function index()
    {
        $studentmodel=new StudentModel();
        $data=$studentmodel->findAll();//larvel get()
        return view('Student',['student' =>$data]);
    }

    public function store(){

        $studentmodel=new StudentModel();
        $name=$this->request->getPost('name');
        $email=$this->request->getPost('email');
        $file=$this->request->getFile('file');
        if($file->isValid() && !$file->hasMoved()){
            $filename=$file->getRandomName();
            $file->move(FCPATH .'/uploads',$filename);//larvel store()
        }
        $data=[
            'name'=>$name,
            'email'=>$email,
            'file'=>$filename,
        ];

        if( $studentmodel->insert($data)){
            return redirect()->to('student');

        }else{
            return redirect()->to('student');
        }

    }

    public function edit(){

        $studentmodel=new StudentModel();
        $id=$this->request->getPost('id');
        $data= $studentmodel->find($id);
        return view('Studentedit',['s'=>$data]);


    }


    public function update(){

        $studentmodel=new StudentModel();
        // $name=$this->request->getPost('name');
        // $email=$this->request->getPost('email');
        // $file=$this->request->getFile('file');
        // if($file->isValid() && !$file->hasMoved()){
        //     $filename=$file->getRandomName();
        //     $file->move(FCPATH .'/uploads',$filename);
        // }
        // $data=[
        //     'name'=>$name,
        //     'email'=>$email,
        //     'file'=>$filename,
        // ];

        $id=$this->request->getPost('id');
        $data=$this->request->getPost();
        //print_r($data);exit;
        $studentmodel->update($id,$data);

       return redirect()->to('student');

    }
}
