<?php

$a=5;
$b=6;

$a=$a + $b;//5+6=11
$b= $a - $b;//11-6=5
$a= $a - $b;//11-5=6

echo "a is " .$a;
echo "<br>";
echo "b is " .$b;


?>