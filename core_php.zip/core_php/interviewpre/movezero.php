<?php
function movezero($num){
    $lastzeroindex=0;

    

    for($i=0;$i<count($num);$i++){
        if($num[$i] !=0){
            $temp=$num[$lastzeroindex];
            $num[$lastzeroindex]=$num[$i];
            $num[$i]=$temp;

            $lastzeroindex++;
            
            

        }
    }
    echo "<pre>";
    print_r($num);
    echo "</pre>";

}
movezero([1,2,0,3,4,6,1,0,1,2,4,0,-1,-2,-6]);
?>