<?php

function checkcapitalnum($alph){
   // echo "<pre>";print_r($alph);echo "</pre>";

    $alphaet='qwertyuiopasdfghjklzxcvbnm';
    $capalphabet=strtoupper($alphaet);
    $alphabetarr=str_split( $capalphabet);

    for($i=0;$i<count($alphabetarr);$i++){

        for($j=0;$j<count($alph);$j++){
            if($alph[$j]== $alphabetarr[$i]){
                echo $alph[$j];
            }
        }
    }
   // print_r($alphabetarr);


    
}
checkcapitalnum(['a','A','u','o','j','B','B']);
?>