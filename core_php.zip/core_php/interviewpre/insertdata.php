<?php
include("conn.php");

if(isset($_POST['name']) && isset($_POST['email'] ))
{
$name=$_POST['name'];
$email=$_POST['email'];


if($name && $email){

    $userdetailinsertquery="INSERT INTO USERS (NAME,EMAIL) VALUES ('$name','$email')";
     
    $insertuser=mysqli_query($conn,$userdetailinsertquery);
    if( $insertuser){
        echo "user detail inserted";
    }else{
        die('failed to insert' .mysqli_error($conn));
    }
}
}

$getquery="SELECT * FROM USERS";
$users=mysqli_query($conn,$getquery);


if($users->num_rows > 0)
{
    $users=mysqli_fetch_assoc($users);
   //  redirect();
echo "<pre>";print_r($users);echo "</pre>";exit;
}else{
    echo "no data present";
}
?>