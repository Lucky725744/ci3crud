<?php
for($i=0;$i<5;$i++){
   // echo "*<br>";
    for($j=0;$j<=$i;$j++){
        echo "*";
    }
    echo"<br>";
}
?>