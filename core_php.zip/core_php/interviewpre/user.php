<html>
    <body>
        <form method="POST" action="insertdata.php" enctype="multipart/form-data">

        <label>username :<input type="text" name='name'></label>
        <br><br>
        <label>email :<input type="text" name='email'></label>
        <br>
            <input type="submit" name="submit" value="submit">

</form>


</body>
    </html>