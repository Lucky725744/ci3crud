<?php
function findduplicate($num){
    echo "before unique";
    echo "<br><pre>";
    print_r($num);
    echo "</pre>";

    $duplicatearr=[];

    for($i=0;$i<count($num);$i++){
        $counts=0;

        for($j=0;$j<count($num);$j++){

            if($num[$j]== $num[$i]){
                $counts++;
            }
        }

        if($counts >=2){
            $duplicatearr[]=$num[$i];

        }

    }
    echo "unique";
    echo "<br><pre>";
    print_r(array_unique($duplicatearr));
    echo "</pre>";

}
findduplicate([1,2,3,4,5,6,7,8,9,1,2,3,4,1,23])
?>