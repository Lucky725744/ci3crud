<html>
    <style>
        .odd{
            background-color:white;
        }
        .even{
            background-color:black;
        }
        .box{
            
            padding:40px;
        }
        .chessbox{
            border:1px solid #ddd;
        }
        </style>
    <body>
        <?php
        $row=8;$col=8;?>

    <?php for ($i=0;$i<$row;$i++){ ?>

        <div class="box">

        <?php for ($j=0;$j<$col;$j++){
            if(($i+$j) % 2 == 0) {
                ?>
            
            <span class="even box chessbox"></span>
            <?php  }else{ ?>
                <span class=" box odd chessbox"></span>
                <?php  } ?> 

            <?php  } ?>
        </div>
        
   <?php  } ?>
    
</body>
    </html>