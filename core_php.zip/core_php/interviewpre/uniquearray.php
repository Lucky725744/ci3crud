<?php
function uniquearray($num){
    echo "before unique";
    echo "<br><pre>";
    print_r($num);
    echo "</pre>";

    $uniquearr=[];
    for($i=0;$i<count($num);$i++){
        $isduplicate=false;
        for($j=0;$j<count($uniquearr);$j++){
            if($uniquearr[$j]==$num[$i]){
                $isduplicate=true;
            }
        }
        // if(!($isduplicate)){
        //     $uniquearr[]=$num[$i];
        // }
        if($isduplicate){
            $uniquearr[]=$num[$i];
        }
    }
    echo "after unique";
    echo "<br><pre>";
    print_r( $uniquearr);
    echo "</pre>";

}
uniquearray([1,2,3,4,5,6,7,8,9,1,2,3,4,1,23])
?>