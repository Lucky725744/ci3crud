<?php
$conn=mysqli_connect('localhost','root',"","corephp");

if($conn){
    echo "connected sucessfully";

}else{
    die("failed to connect" .mysqli_connect_error());
}

$query="CREATE TABLE IF NOT EXISTS USERS (ID INT PRIMARY KEY AUTO_INCREMENT,NAME VARCHAR(255) NOT NULL,EMAIL VARCHAR(255) NOT NULL)";
$createtable=mysqli_query($conn,$query);

if($createtable){
    echo "table created";
}else{
    die('failed to connect' .mysqli_error($conn));
}
?>