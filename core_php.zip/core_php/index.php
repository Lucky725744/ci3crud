<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Summernote Editor with Font Size and Color</title>

  <!-- Include Bootstrap 4 CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  
  <!-- Include Summernote CSS for Bootstrap 4 (latest version 0.8.18) -->
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.css" rel="stylesheet">

  <!-- Include jQuery (required for Summernote) -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  
  <!-- Include Summernote JS for Bootstrap 4 (latest version 0.8.18) -->
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
  
</head>
<body>

  <div class="container mt-5">
    <h2>Summernote Editor with Font Size and Color Options</h2>
    <!-- Textarea that will be turned into a Summernote editor -->
    <textarea id="summernote"></textarea>
  </div>

  <script>
    $(document).ready(function() {
      // Initialize Summernote with font size and font color options
      $('#summernote').summernote({
        placeholder: "Type your text here...",
        height: 300,  // Set the height of the editor
        toolbar: [
          ['font', ['fontname', 'fontsize', 'bold', 'italic', 'underline', 'clear', 'forecolor', 'backcolor']],  // Font size and color in the toolbar
          ['para', ['ul', 'ol', 'paragraph']],
          ['insert', ['link', 'picture', 'video']]
        ],
        fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Georgia', 'Lucida Sans', 'Tahoma', 'Times New Roman', 'Verdana'],  // List of fonts
        fontSizes: ['8', '10', '12', '14', '16', '18', '20', '22', '24', '26', '28', '36', '48', '72'],  // Font sizes
        // Optional: Add more customization for the toolbar as needed
      });
    });
  </script>

</body>
</html>
