<?php

require('Student.php');
require('Student_namespace.php');
use Student_name\Student as SN;
use Student\Student as S;

$student=new SN();
echo $student->test();

$student=new S();
echo $student->test();