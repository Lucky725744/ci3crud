<?php

namespace Student;
class Student{

    function test(){
        echo "this is student class";
    }

}

