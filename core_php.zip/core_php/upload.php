

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    echo 'test';
    if(isset($_FILES['file'])){

   
    $image=basename($_FILES['file'] ['name']);
    $temp=$_FILES['file'] ['tmp_name'];
    $target='upload/';
    $targetfile=$target.$image;
    $extension=strtolower(pathinfo($targetfile,PATHINFO_EXTENSION));
    print_r($temp);
    if(move_uploaded_file($temp,$targetfile)){echo 'fileuploaded';}else{echo 'fail';}
}
}
?>

<html>
    <body>
        <form method='post' action='upload.php' enctype='multipart/form-data'>
            <label>upload</label><input type='file'name='file' value='file'>
            <input type='submit' name='submit' value='submit'>
        </form>
</body>
    </html>