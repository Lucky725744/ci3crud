<?php
namespace Student_name;
class Student{
    function test(){
        echo "this is student name space";
    }
}

