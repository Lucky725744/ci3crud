<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->library('upload');
        //$this->load->helper('url');
        $this->load->database();
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
        $data=$this->db->get('students')->result_array();
		$this->load->view('student',['student'=>$data]);
	}

    public function get(){
        $data=$this->db->get('students')->result_array();
        echo json_encode(['status'=>true,'student'=>$data]);
        exit();
    }
    public function edit()
	{
        $id=$this->input->post('id');
        $data=$this->db->get_where('students', ['id' => $id])->row_array(); 
		$this->load->view('studentedit',['s'=>$data]);
	}

    public function store(){
        $config['upload_path']= FCPATH  .'upload';
        $config['allowed_types']='png|jpg|pdf';
        $config['file_name']= time() .'-' .$_FILES['file']['name'];

        $this->upload->initialize($config);
        if($this->upload->do_upload('file')){
            $file=$this->upload->data();
            $filename=$file['file_name'];
        }else{

            $error=$this->upload->display_errors();
            echo $error;
        }
        $data=[
            'name'=>$this->input->post('name'),
            'email'=>$this->input->post('email'),
            'file'=>$filename,
        ];
        $result=$this->db->insert('students',$data);
        if($result){
            //return redirect('Student');
            echo json_encode(['status'=>true,'messsage'=>'data inserted']);
            exit();
        }   
    }

    function update(){
        $id=$this->input->post('id');

        $data=[
            'name'=>$this->input->post('name'),
            'email'=>$this->input->post('email'),
            'file'=>$this->input->post('file'),
        ];
        $this->db->where('id',$id);
        $this->db->update('students',$data);
        if ($this->db->affected_rows() > 0) {
            return redirect('Student');
        }
    }
}
