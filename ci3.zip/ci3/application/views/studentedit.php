
<html>

<head>
    <style>
        table {
            width: 100%;
        }
        
        tr,
        td,
        th {
            border: 1px solid #ddd;
            padding: 8px;
        }
        
        img {
            width: 10%;
            height: 10%;
        }
    </style>
</head>

<body>
    <form method="POST" action="<?php echo base_url('Student/update');?>" enctype="multipart/form-data">
    <input type='hidden' value="<?php echo $s['id'];?>" name='id'>
        <label>Name:<input type='text' value="<?php echo $s['name'];?>" name='name'></label><br>
        <label>Email:<input type='email' value="<?php echo $s['email'];?>" name='email'></label><br>
        <label>File:<input type='file' value="<?php echo $s['file'];?>" name='file'></label><br>
        <input type='submit' name='Update'>
    </form>
</body>

</html>