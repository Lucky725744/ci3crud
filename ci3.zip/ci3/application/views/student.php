<!DOCTYPE html>
<html>

<head>
    <style>
        table {
            width: 100%;
        }

        tr,
        td,
        th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        img {
            width: 10%;
            height: 10%;
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <form id="studentForm" method="POST" enctype="multipart/form-data">
        <label>Name:<input type="text" name="name"></label><br>
        <label>Email:<input type="email" name="email"></label><br>
        <label>File:<input type="file" name="file"></label><br>
        <input type="submit" value="Submit">
    </form>

    <table>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>email</th>
            <th>file</th>
            <th>edit</th>
        </tr>
        <tbody id='tablebody'>
            <tbody>
        
        <!-- <?php foreach($student as $s) { ?>
        <tr>
            <td><?php echo $s['id']; ?></td>
            <td><?php echo $s['name']; ?></td>
            <td><?php echo $s['email']; ?></td>
            <td>
                <img src="<?php echo base_url().$s['file']; ?>" alt="image">
            </td>
            <form method="POST" action="<?php echo base_url('Student/edit'); ?>" enctype="multipart/form-data">
                <input type="hidden" value="<?php echo $s['id'];?>" name="id">
                <td><input type="submit" value="Edit"></td>
            </form>
        </tr>
        <?php } ?> -->
    </table>

    <script>
        $(document).ready(function() {
            var baseUrl="<?php echo base_url();?>"
            $('#studentForm').on('submit', function(event) {
                event.preventDefault();

                var formData = new FormData(this);

                $.ajax({
                    url: "<?php echo base_url('Student/store'); ?>",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        var response=JSON.parse(response);
                        if(response.status){
                        alert('Data submitted successfully!');
                        console.log(response);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while submitting the form.');
                    }
                });
            });
            getdata();
        });

        function getdata(){
            $.ajax({
                    url: "<?php echo base_url('Student/get'); ?>",
                    type: "POST",
                   // data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        var response=JSON.parse(response);
                        if(response.status){
                       
                       // console.log(response.student);

                       var html = ''; 

                        for(i=0;i<(response.student).length;i++){
                            console.log(response.student[i]);
                            html += `<tr>
                                <td>${response.student[i].id}</td>
                                <td>${response.student[i].name}</td>
                                <td>${response.student[i].email}</td>
                                <td><img src="${'<?php echo base_url();?>'}${response.student[i].file}" alt="file" width="50"></td>
                             </tr>`;
                        }
                        console.log (html);
                        $('#tablebody').append(html);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('An error occurred while submitting the form.');
                    }
                });
        }

        
    </script>

</body>

</html>
