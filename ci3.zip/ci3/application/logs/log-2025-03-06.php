<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-03-06 09:40:50 --> Config Class Initialized
INFO - 2025-03-06 09:40:50 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:40:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:40:50 --> Utf8 Class Initialized
INFO - 2025-03-06 09:40:50 --> URI Class Initialized
INFO - 2025-03-06 09:40:50 --> Router Class Initialized
INFO - 2025-03-06 09:40:50 --> Output Class Initialized
INFO - 2025-03-06 09:40:50 --> Security Class Initialized
DEBUG - 2025-03-06 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:40:50 --> Input Class Initialized
INFO - 2025-03-06 09:40:50 --> Language Class Initialized
INFO - 2025-03-06 09:40:50 --> Loader Class Initialized
INFO - 2025-03-06 09:40:50 --> Helper loaded: url_helper
INFO - 2025-03-06 09:40:50 --> Helper loaded: file_helper
INFO - 2025-03-06 09:40:50 --> Controller Class Initialized
ERROR - 2025-03-06 09:40:50 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 39
ERROR - 2025-03-06 09:40:50 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 39
INFO - 2025-03-06 09:41:38 --> Config Class Initialized
INFO - 2025-03-06 09:41:38 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:41:38 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:41:38 --> Utf8 Class Initialized
INFO - 2025-03-06 09:41:38 --> URI Class Initialized
INFO - 2025-03-06 09:41:38 --> Router Class Initialized
INFO - 2025-03-06 09:41:38 --> Output Class Initialized
INFO - 2025-03-06 09:41:38 --> Security Class Initialized
DEBUG - 2025-03-06 09:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:41:38 --> Input Class Initialized
INFO - 2025-03-06 09:41:38 --> Language Class Initialized
INFO - 2025-03-06 09:41:38 --> Loader Class Initialized
INFO - 2025-03-06 09:41:38 --> Helper loaded: url_helper
INFO - 2025-03-06 09:41:38 --> Helper loaded: file_helper
INFO - 2025-03-06 09:41:38 --> Controller Class Initialized
ERROR - 2025-03-06 09:41:38 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 39
ERROR - 2025-03-06 09:41:38 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 39
INFO - 2025-03-06 09:43:45 --> Config Class Initialized
INFO - 2025-03-06 09:43:45 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:43:45 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:43:45 --> Utf8 Class Initialized
INFO - 2025-03-06 09:43:45 --> URI Class Initialized
INFO - 2025-03-06 09:43:45 --> Router Class Initialized
INFO - 2025-03-06 09:43:45 --> Output Class Initialized
INFO - 2025-03-06 09:43:45 --> Security Class Initialized
DEBUG - 2025-03-06 09:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:43:45 --> Input Class Initialized
INFO - 2025-03-06 09:43:45 --> Language Class Initialized
INFO - 2025-03-06 09:43:45 --> Loader Class Initialized
INFO - 2025-03-06 09:43:45 --> Helper loaded: url_helper
INFO - 2025-03-06 09:43:45 --> Helper loaded: file_helper
INFO - 2025-03-06 09:43:45 --> Controller Class Initialized
ERROR - 2025-03-06 09:43:45 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 38
ERROR - 2025-03-06 09:43:45 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 38
INFO - 2025-03-06 09:43:48 --> Config Class Initialized
INFO - 2025-03-06 09:43:48 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:43:48 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:43:48 --> Utf8 Class Initialized
INFO - 2025-03-06 09:43:48 --> URI Class Initialized
INFO - 2025-03-06 09:43:48 --> Router Class Initialized
INFO - 2025-03-06 09:43:48 --> Output Class Initialized
INFO - 2025-03-06 09:43:48 --> Security Class Initialized
DEBUG - 2025-03-06 09:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:43:48 --> Input Class Initialized
INFO - 2025-03-06 09:43:48 --> Language Class Initialized
INFO - 2025-03-06 09:43:48 --> Loader Class Initialized
INFO - 2025-03-06 09:43:48 --> Helper loaded: url_helper
INFO - 2025-03-06 09:43:48 --> Helper loaded: file_helper
INFO - 2025-03-06 09:43:48 --> Controller Class Initialized
ERROR - 2025-03-06 09:43:48 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 38
ERROR - 2025-03-06 09:43:48 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 38
INFO - 2025-03-06 09:43:59 --> Config Class Initialized
INFO - 2025-03-06 09:43:59 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:43:59 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:43:59 --> Utf8 Class Initialized
INFO - 2025-03-06 09:43:59 --> URI Class Initialized
INFO - 2025-03-06 09:43:59 --> Router Class Initialized
INFO - 2025-03-06 09:43:59 --> Output Class Initialized
INFO - 2025-03-06 09:43:59 --> Security Class Initialized
DEBUG - 2025-03-06 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:43:59 --> Input Class Initialized
INFO - 2025-03-06 09:43:59 --> Language Class Initialized
INFO - 2025-03-06 09:43:59 --> Loader Class Initialized
INFO - 2025-03-06 09:43:59 --> Helper loaded: url_helper
INFO - 2025-03-06 09:43:59 --> Helper loaded: file_helper
INFO - 2025-03-06 09:43:59 --> Controller Class Initialized
ERROR - 2025-03-06 09:43:59 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 38
ERROR - 2025-03-06 09:43:59 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 38
INFO - 2025-03-06 09:44:52 --> Config Class Initialized
INFO - 2025-03-06 09:44:52 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:44:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:44:52 --> Utf8 Class Initialized
INFO - 2025-03-06 09:44:52 --> URI Class Initialized
INFO - 2025-03-06 09:44:52 --> Router Class Initialized
INFO - 2025-03-06 09:44:52 --> Output Class Initialized
INFO - 2025-03-06 09:44:52 --> Security Class Initialized
DEBUG - 2025-03-06 09:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:44:52 --> Input Class Initialized
INFO - 2025-03-06 09:44:52 --> Language Class Initialized
INFO - 2025-03-06 09:44:52 --> Loader Class Initialized
INFO - 2025-03-06 09:44:52 --> Helper loaded: url_helper
INFO - 2025-03-06 09:44:52 --> Helper loaded: file_helper
INFO - 2025-03-06 09:44:52 --> Controller Class Initialized
ERROR - 2025-03-06 09:44:52 --> Severity: error --> Exception: Call to undefined method CI_Loader::libraray() C:\xampp\htdocs\ci3\application\controllers\Student.php 33
INFO - 2025-03-06 09:45:54 --> Config Class Initialized
INFO - 2025-03-06 09:45:54 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:45:54 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:45:54 --> Utf8 Class Initialized
INFO - 2025-03-06 09:45:54 --> URI Class Initialized
INFO - 2025-03-06 09:45:54 --> Router Class Initialized
INFO - 2025-03-06 09:45:54 --> Output Class Initialized
INFO - 2025-03-06 09:45:54 --> Security Class Initialized
DEBUG - 2025-03-06 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:45:54 --> Input Class Initialized
INFO - 2025-03-06 09:45:54 --> Language Class Initialized
INFO - 2025-03-06 09:45:54 --> Loader Class Initialized
INFO - 2025-03-06 09:45:54 --> Helper loaded: url_helper
INFO - 2025-03-06 09:45:54 --> Helper loaded: file_helper
INFO - 2025-03-06 09:45:54 --> Controller Class Initialized
ERROR - 2025-03-06 09:45:54 --> Severity: Notice --> Undefined property: CI_Loader::$libraries C:\xampp\htdocs\ci3\application\controllers\Student.php 33
ERROR - 2025-03-06 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\ci3\application\controllers\Student.php 33
ERROR - 2025-03-06 09:45:54 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 39
ERROR - 2025-03-06 09:45:54 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 39
INFO - 2025-03-06 09:46:21 --> Config Class Initialized
INFO - 2025-03-06 09:46:21 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:46:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:46:21 --> Utf8 Class Initialized
INFO - 2025-03-06 09:46:21 --> URI Class Initialized
INFO - 2025-03-06 09:46:21 --> Router Class Initialized
INFO - 2025-03-06 09:46:21 --> Output Class Initialized
INFO - 2025-03-06 09:46:21 --> Security Class Initialized
DEBUG - 2025-03-06 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:46:21 --> Input Class Initialized
INFO - 2025-03-06 09:46:21 --> Language Class Initialized
INFO - 2025-03-06 09:46:21 --> Loader Class Initialized
INFO - 2025-03-06 09:46:21 --> Helper loaded: url_helper
INFO - 2025-03-06 09:46:21 --> Helper loaded: file_helper
INFO - 2025-03-06 09:46:21 --> Controller Class Initialized
INFO - 2025-03-06 09:46:21 --> Upload Class Initialized
INFO - 2025-03-06 09:46:36 --> Config Class Initialized
INFO - 2025-03-06 09:46:36 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:46:36 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:46:36 --> Utf8 Class Initialized
INFO - 2025-03-06 09:46:36 --> URI Class Initialized
INFO - 2025-03-06 09:46:36 --> Router Class Initialized
INFO - 2025-03-06 09:46:36 --> Output Class Initialized
INFO - 2025-03-06 09:46:36 --> Security Class Initialized
DEBUG - 2025-03-06 09:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:46:36 --> Input Class Initialized
INFO - 2025-03-06 09:46:36 --> Language Class Initialized
INFO - 2025-03-06 09:46:36 --> Loader Class Initialized
INFO - 2025-03-06 09:46:36 --> Helper loaded: url_helper
INFO - 2025-03-06 09:46:36 --> Helper loaded: file_helper
INFO - 2025-03-06 09:46:36 --> Controller Class Initialized
ERROR - 2025-03-06 09:46:36 --> Severity: Notice --> Undefined property: Student::$upload C:\xampp\htdocs\ci3\application\controllers\Student.php 39
ERROR - 2025-03-06 09:46:36 --> Severity: error --> Exception: Call to a member function initialize() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 39
INFO - 2025-03-06 09:47:23 --> Config Class Initialized
INFO - 2025-03-06 09:47:23 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:47:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:47:23 --> Utf8 Class Initialized
INFO - 2025-03-06 09:47:23 --> URI Class Initialized
INFO - 2025-03-06 09:47:23 --> Router Class Initialized
INFO - 2025-03-06 09:47:23 --> Output Class Initialized
INFO - 2025-03-06 09:47:23 --> Security Class Initialized
DEBUG - 2025-03-06 09:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:47:23 --> Input Class Initialized
INFO - 2025-03-06 09:47:23 --> Language Class Initialized
ERROR - 2025-03-06 09:47:23 --> Severity: error --> Exception: Call to a member function library() on null C:\xampp\htdocs\ci3\application\controllers\Student.php 7
INFO - 2025-03-06 09:47:48 --> Config Class Initialized
INFO - 2025-03-06 09:47:48 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:47:48 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:47:48 --> Utf8 Class Initialized
INFO - 2025-03-06 09:47:48 --> URI Class Initialized
INFO - 2025-03-06 09:47:48 --> Router Class Initialized
INFO - 2025-03-06 09:47:48 --> Output Class Initialized
INFO - 2025-03-06 09:47:48 --> Security Class Initialized
DEBUG - 2025-03-06 09:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:47:48 --> Input Class Initialized
INFO - 2025-03-06 09:47:48 --> Language Class Initialized
INFO - 2025-03-06 09:47:48 --> Loader Class Initialized
INFO - 2025-03-06 09:47:48 --> Helper loaded: url_helper
INFO - 2025-03-06 09:47:48 --> Helper loaded: file_helper
INFO - 2025-03-06 09:47:48 --> Controller Class Initialized
INFO - 2025-03-06 09:47:48 --> Upload Class Initialized
INFO - 2025-03-06 09:47:48 --> Database Driver Class Initialized
INFO - 2025-03-06 09:48:51 --> Config Class Initialized
INFO - 2025-03-06 09:48:51 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:48:51 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:48:51 --> Utf8 Class Initialized
INFO - 2025-03-06 09:48:51 --> URI Class Initialized
INFO - 2025-03-06 09:48:51 --> Router Class Initialized
INFO - 2025-03-06 09:48:51 --> Output Class Initialized
INFO - 2025-03-06 09:48:51 --> Security Class Initialized
DEBUG - 2025-03-06 09:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:48:51 --> Input Class Initialized
INFO - 2025-03-06 09:48:51 --> Language Class Initialized
INFO - 2025-03-06 09:48:51 --> Loader Class Initialized
INFO - 2025-03-06 09:48:51 --> Helper loaded: url_helper
INFO - 2025-03-06 09:48:51 --> Helper loaded: file_helper
INFO - 2025-03-06 09:48:51 --> Controller Class Initialized
INFO - 2025-03-06 09:48:51 --> Upload Class Initialized
INFO - 2025-03-06 09:48:51 --> Database Driver Class Initialized
INFO - 2025-03-06 09:49:08 --> Config Class Initialized
INFO - 2025-03-06 09:49:08 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:49:08 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:49:08 --> Utf8 Class Initialized
INFO - 2025-03-06 09:49:08 --> URI Class Initialized
INFO - 2025-03-06 09:49:08 --> Router Class Initialized
INFO - 2025-03-06 09:49:08 --> Output Class Initialized
INFO - 2025-03-06 09:49:08 --> Security Class Initialized
DEBUG - 2025-03-06 09:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:49:08 --> Input Class Initialized
INFO - 2025-03-06 09:49:08 --> Language Class Initialized
INFO - 2025-03-06 09:49:08 --> Loader Class Initialized
INFO - 2025-03-06 09:49:08 --> Helper loaded: url_helper
INFO - 2025-03-06 09:49:08 --> Helper loaded: file_helper
INFO - 2025-03-06 09:49:08 --> Controller Class Initialized
INFO - 2025-03-06 09:49:08 --> Upload Class Initialized
INFO - 2025-03-06 09:49:08 --> Database Driver Class Initialized
INFO - 2025-03-06 09:50:27 --> Config Class Initialized
INFO - 2025-03-06 09:50:27 --> Hooks Class Initialized
DEBUG - 2025-03-06 09:50:27 --> UTF-8 Support Enabled
INFO - 2025-03-06 09:50:27 --> Utf8 Class Initialized
INFO - 2025-03-06 09:50:27 --> URI Class Initialized
INFO - 2025-03-06 09:50:27 --> Router Class Initialized
INFO - 2025-03-06 09:50:27 --> Output Class Initialized
INFO - 2025-03-06 09:50:27 --> Security Class Initialized
DEBUG - 2025-03-06 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 09:50:27 --> Input Class Initialized
INFO - 2025-03-06 09:50:27 --> Language Class Initialized
INFO - 2025-03-06 09:50:27 --> Loader Class Initialized
INFO - 2025-03-06 09:50:27 --> Helper loaded: url_helper
INFO - 2025-03-06 09:50:27 --> Helper loaded: file_helper
INFO - 2025-03-06 09:50:27 --> Controller Class Initialized
INFO - 2025-03-06 09:50:27 --> Upload Class Initialized
INFO - 2025-03-06 09:50:27 --> Database Driver Class Initialized
INFO - 2025-03-06 10:06:15 --> Config Class Initialized
INFO - 2025-03-06 10:06:15 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:06:15 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:06:15 --> Utf8 Class Initialized
INFO - 2025-03-06 10:06:15 --> URI Class Initialized
INFO - 2025-03-06 10:06:15 --> Router Class Initialized
INFO - 2025-03-06 10:06:15 --> Output Class Initialized
INFO - 2025-03-06 10:06:15 --> Security Class Initialized
DEBUG - 2025-03-06 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:06:15 --> Input Class Initialized
INFO - 2025-03-06 10:06:15 --> Language Class Initialized
INFO - 2025-03-06 10:06:15 --> Loader Class Initialized
INFO - 2025-03-06 10:06:15 --> Helper loaded: url_helper
INFO - 2025-03-06 10:06:15 --> Helper loaded: file_helper
INFO - 2025-03-06 10:06:15 --> Controller Class Initialized
INFO - 2025-03-06 10:06:15 --> Upload Class Initialized
INFO - 2025-03-06 10:06:15 --> Database Driver Class Initialized
INFO - 2025-03-06 10:06:15 --> Config Class Initialized
INFO - 2025-03-06 10:06:15 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:06:15 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:06:15 --> Utf8 Class Initialized
INFO - 2025-03-06 10:06:15 --> URI Class Initialized
INFO - 2025-03-06 10:06:15 --> Router Class Initialized
INFO - 2025-03-06 10:06:15 --> Output Class Initialized
INFO - 2025-03-06 10:06:15 --> Security Class Initialized
DEBUG - 2025-03-06 10:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:06:15 --> Input Class Initialized
INFO - 2025-03-06 10:06:15 --> Language Class Initialized
ERROR - 2025-03-06 10:06:15 --> 404 Page Not Found: Indexphp/Student
INFO - 2025-03-06 10:07:57 --> Config Class Initialized
INFO - 2025-03-06 10:07:57 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:07:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:07:57 --> Utf8 Class Initialized
INFO - 2025-03-06 10:07:57 --> URI Class Initialized
INFO - 2025-03-06 10:07:57 --> Router Class Initialized
INFO - 2025-03-06 10:07:57 --> Output Class Initialized
INFO - 2025-03-06 10:07:57 --> Security Class Initialized
DEBUG - 2025-03-06 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:07:57 --> Input Class Initialized
INFO - 2025-03-06 10:07:57 --> Language Class Initialized
INFO - 2025-03-06 10:07:57 --> Loader Class Initialized
INFO - 2025-03-06 10:07:57 --> Helper loaded: url_helper
INFO - 2025-03-06 10:07:57 --> Helper loaded: file_helper
INFO - 2025-03-06 10:07:57 --> Controller Class Initialized
INFO - 2025-03-06 10:07:57 --> Upload Class Initialized
INFO - 2025-03-06 10:07:57 --> Database Driver Class Initialized
INFO - 2025-03-06 10:07:57 --> Config Class Initialized
INFO - 2025-03-06 10:07:57 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:07:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:07:57 --> Utf8 Class Initialized
INFO - 2025-03-06 10:07:57 --> URI Class Initialized
INFO - 2025-03-06 10:07:57 --> Router Class Initialized
INFO - 2025-03-06 10:07:57 --> Output Class Initialized
INFO - 2025-03-06 10:07:57 --> Security Class Initialized
DEBUG - 2025-03-06 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:07:57 --> Input Class Initialized
INFO - 2025-03-06 10:07:57 --> Language Class Initialized
ERROR - 2025-03-06 10:07:57 --> 404 Page Not Found: Indexphp/Student
INFO - 2025-03-06 10:08:01 --> Config Class Initialized
INFO - 2025-03-06 10:08:01 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:08:01 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:08:01 --> Utf8 Class Initialized
INFO - 2025-03-06 10:08:01 --> URI Class Initialized
INFO - 2025-03-06 10:08:01 --> Router Class Initialized
INFO - 2025-03-06 10:08:01 --> Output Class Initialized
INFO - 2025-03-06 10:08:01 --> Security Class Initialized
DEBUG - 2025-03-06 10:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:08:01 --> Input Class Initialized
INFO - 2025-03-06 10:08:01 --> Language Class Initialized
ERROR - 2025-03-06 10:08:01 --> 404 Page Not Found: Indexphp/Student
INFO - 2025-03-06 10:08:10 --> Config Class Initialized
INFO - 2025-03-06 10:08:10 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:08:10 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:08:10 --> Utf8 Class Initialized
INFO - 2025-03-06 10:08:10 --> URI Class Initialized
INFO - 2025-03-06 10:08:10 --> Router Class Initialized
INFO - 2025-03-06 10:08:10 --> Output Class Initialized
INFO - 2025-03-06 10:08:10 --> Security Class Initialized
DEBUG - 2025-03-06 10:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:08:10 --> Input Class Initialized
INFO - 2025-03-06 10:08:10 --> Language Class Initialized
INFO - 2025-03-06 10:08:10 --> Loader Class Initialized
INFO - 2025-03-06 10:08:10 --> Helper loaded: url_helper
INFO - 2025-03-06 10:08:10 --> Helper loaded: file_helper
INFO - 2025-03-06 10:08:10 --> Controller Class Initialized
INFO - 2025-03-06 10:08:10 --> Upload Class Initialized
INFO - 2025-03-06 10:08:10 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:08:10 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\ci3\application\views\student.php 40
ERROR - 2025-03-06 10:08:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ci3\application\views\student.php 40
INFO - 2025-03-06 10:08:10 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:08:10 --> Final output sent to browser
DEBUG - 2025-03-06 10:08:10 --> Total execution time: 0.0530
INFO - 2025-03-06 10:08:15 --> Config Class Initialized
INFO - 2025-03-06 10:08:15 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:08:15 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:08:15 --> Utf8 Class Initialized
INFO - 2025-03-06 10:08:15 --> URI Class Initialized
INFO - 2025-03-06 10:08:15 --> Router Class Initialized
INFO - 2025-03-06 10:08:15 --> Output Class Initialized
INFO - 2025-03-06 10:08:15 --> Security Class Initialized
DEBUG - 2025-03-06 10:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:08:15 --> Input Class Initialized
INFO - 2025-03-06 10:08:15 --> Language Class Initialized
INFO - 2025-03-06 10:08:15 --> Loader Class Initialized
INFO - 2025-03-06 10:08:15 --> Helper loaded: url_helper
INFO - 2025-03-06 10:08:15 --> Helper loaded: file_helper
INFO - 2025-03-06 10:08:15 --> Controller Class Initialized
INFO - 2025-03-06 10:08:15 --> Upload Class Initialized
INFO - 2025-03-06 10:08:15 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:08:15 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\ci3\application\views\student.php 40
ERROR - 2025-03-06 10:08:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ci3\application\views\student.php 40
INFO - 2025-03-06 10:08:15 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:08:15 --> Final output sent to browser
DEBUG - 2025-03-06 10:08:15 --> Total execution time: 0.0327
INFO - 2025-03-06 10:08:17 --> Config Class Initialized
INFO - 2025-03-06 10:08:17 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:08:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:08:17 --> Utf8 Class Initialized
INFO - 2025-03-06 10:08:17 --> URI Class Initialized
INFO - 2025-03-06 10:08:17 --> Router Class Initialized
INFO - 2025-03-06 10:08:17 --> Output Class Initialized
INFO - 2025-03-06 10:08:17 --> Security Class Initialized
DEBUG - 2025-03-06 10:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:08:17 --> Input Class Initialized
INFO - 2025-03-06 10:08:17 --> Language Class Initialized
INFO - 2025-03-06 10:08:17 --> Loader Class Initialized
INFO - 2025-03-06 10:08:17 --> Helper loaded: url_helper
INFO - 2025-03-06 10:08:17 --> Helper loaded: file_helper
INFO - 2025-03-06 10:08:17 --> Controller Class Initialized
INFO - 2025-03-06 10:08:17 --> Upload Class Initialized
INFO - 2025-03-06 10:08:17 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:08:17 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\ci3\application\views\student.php 40
ERROR - 2025-03-06 10:08:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ci3\application\views\student.php 40
INFO - 2025-03-06 10:08:17 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:08:17 --> Final output sent to browser
DEBUG - 2025-03-06 10:08:17 --> Total execution time: 0.0564
INFO - 2025-03-06 10:08:50 --> Config Class Initialized
INFO - 2025-03-06 10:08:50 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:08:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:08:50 --> Utf8 Class Initialized
INFO - 2025-03-06 10:08:50 --> URI Class Initialized
INFO - 2025-03-06 10:08:50 --> Router Class Initialized
INFO - 2025-03-06 10:08:50 --> Output Class Initialized
INFO - 2025-03-06 10:08:50 --> Security Class Initialized
DEBUG - 2025-03-06 10:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:08:50 --> Input Class Initialized
INFO - 2025-03-06 10:08:50 --> Language Class Initialized
INFO - 2025-03-06 10:08:50 --> Loader Class Initialized
INFO - 2025-03-06 10:08:50 --> Helper loaded: url_helper
INFO - 2025-03-06 10:08:50 --> Helper loaded: file_helper
INFO - 2025-03-06 10:08:50 --> Controller Class Initialized
INFO - 2025-03-06 10:08:50 --> Upload Class Initialized
INFO - 2025-03-06 10:08:50 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:08:50 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\ci3\application\views\student.php 40
ERROR - 2025-03-06 10:08:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ci3\application\views\student.php 40
INFO - 2025-03-06 10:08:50 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:08:50 --> Final output sent to browser
DEBUG - 2025-03-06 10:08:50 --> Total execution time: 0.0613
INFO - 2025-03-06 10:09:00 --> Config Class Initialized
INFO - 2025-03-06 10:09:00 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:09:00 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:09:00 --> Utf8 Class Initialized
INFO - 2025-03-06 10:09:00 --> URI Class Initialized
INFO - 2025-03-06 10:09:00 --> Router Class Initialized
INFO - 2025-03-06 10:09:00 --> Output Class Initialized
INFO - 2025-03-06 10:09:00 --> Security Class Initialized
DEBUG - 2025-03-06 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:09:00 --> Input Class Initialized
INFO - 2025-03-06 10:09:00 --> Language Class Initialized
INFO - 2025-03-06 10:09:00 --> Loader Class Initialized
INFO - 2025-03-06 10:09:00 --> Helper loaded: url_helper
INFO - 2025-03-06 10:09:00 --> Helper loaded: file_helper
INFO - 2025-03-06 10:09:00 --> Controller Class Initialized
INFO - 2025-03-06 10:09:00 --> Upload Class Initialized
INFO - 2025-03-06 10:09:00 --> Database Driver Class Initialized
INFO - 2025-03-06 10:09:00 --> Config Class Initialized
INFO - 2025-03-06 10:09:00 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:09:00 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:09:00 --> Utf8 Class Initialized
INFO - 2025-03-06 10:09:00 --> URI Class Initialized
INFO - 2025-03-06 10:09:00 --> Router Class Initialized
INFO - 2025-03-06 10:09:00 --> Output Class Initialized
INFO - 2025-03-06 10:09:00 --> Security Class Initialized
DEBUG - 2025-03-06 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:09:00 --> Input Class Initialized
INFO - 2025-03-06 10:09:00 --> Language Class Initialized
INFO - 2025-03-06 10:09:00 --> Loader Class Initialized
INFO - 2025-03-06 10:09:00 --> Helper loaded: url_helper
INFO - 2025-03-06 10:09:00 --> Helper loaded: file_helper
INFO - 2025-03-06 10:09:00 --> Controller Class Initialized
INFO - 2025-03-06 10:09:00 --> Upload Class Initialized
INFO - 2025-03-06 10:09:00 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:09:00 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\ci3\application\views\student.php 40
ERROR - 2025-03-06 10:09:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ci3\application\views\student.php 40
INFO - 2025-03-06 10:09:00 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:09:00 --> Final output sent to browser
DEBUG - 2025-03-06 10:09:00 --> Total execution time: 0.0257
INFO - 2025-03-06 10:27:26 --> Config Class Initialized
INFO - 2025-03-06 10:27:26 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:27:26 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:27:26 --> Utf8 Class Initialized
INFO - 2025-03-06 10:27:26 --> URI Class Initialized
INFO - 2025-03-06 10:27:26 --> Router Class Initialized
INFO - 2025-03-06 10:27:26 --> Output Class Initialized
INFO - 2025-03-06 10:27:26 --> Security Class Initialized
DEBUG - 2025-03-06 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:27:26 --> Input Class Initialized
INFO - 2025-03-06 10:27:26 --> Language Class Initialized
INFO - 2025-03-06 10:27:26 --> Loader Class Initialized
INFO - 2025-03-06 10:27:26 --> Helper loaded: url_helper
INFO - 2025-03-06 10:27:26 --> Helper loaded: file_helper
INFO - 2025-03-06 10:27:26 --> Controller Class Initialized
INFO - 2025-03-06 10:27:26 --> Upload Class Initialized
INFO - 2025-03-06 10:27:26 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:27:26 --> Severity: Notice --> Undefined variable: student C:\xampp\htdocs\ci3\application\views\student.php 40
ERROR - 2025-03-06 10:27:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\ci3\application\views\student.php 40
INFO - 2025-03-06 10:27:26 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:27:26 --> Final output sent to browser
DEBUG - 2025-03-06 10:27:26 --> Total execution time: 0.0575
INFO - 2025-03-06 10:30:29 --> Config Class Initialized
INFO - 2025-03-06 10:30:29 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:30:29 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:30:29 --> Utf8 Class Initialized
INFO - 2025-03-06 10:30:29 --> URI Class Initialized
INFO - 2025-03-06 10:30:29 --> Router Class Initialized
INFO - 2025-03-06 10:30:29 --> Output Class Initialized
INFO - 2025-03-06 10:30:29 --> Security Class Initialized
DEBUG - 2025-03-06 10:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:30:29 --> Input Class Initialized
INFO - 2025-03-06 10:30:29 --> Language Class Initialized
INFO - 2025-03-06 10:30:29 --> Loader Class Initialized
INFO - 2025-03-06 10:30:29 --> Helper loaded: url_helper
INFO - 2025-03-06 10:30:29 --> Helper loaded: file_helper
INFO - 2025-03-06 10:30:29 --> Controller Class Initialized
INFO - 2025-03-06 10:30:29 --> Upload Class Initialized
INFO - 2025-03-06 10:30:29 --> Database Driver Class Initialized
INFO - 2025-03-06 10:31:24 --> Config Class Initialized
INFO - 2025-03-06 10:31:24 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:31:24 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:31:24 --> Utf8 Class Initialized
INFO - 2025-03-06 10:31:24 --> URI Class Initialized
INFO - 2025-03-06 10:31:24 --> Router Class Initialized
INFO - 2025-03-06 10:31:24 --> Output Class Initialized
INFO - 2025-03-06 10:31:24 --> Security Class Initialized
DEBUG - 2025-03-06 10:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:31:24 --> Input Class Initialized
INFO - 2025-03-06 10:31:24 --> Language Class Initialized
INFO - 2025-03-06 10:31:24 --> Loader Class Initialized
INFO - 2025-03-06 10:31:24 --> Helper loaded: url_helper
INFO - 2025-03-06 10:31:24 --> Helper loaded: file_helper
INFO - 2025-03-06 10:31:24 --> Controller Class Initialized
INFO - 2025-03-06 10:31:24 --> Upload Class Initialized
INFO - 2025-03-06 10:31:24 --> Database Driver Class Initialized
INFO - 2025-03-06 10:34:31 --> Config Class Initialized
INFO - 2025-03-06 10:34:31 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:34:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:34:31 --> Utf8 Class Initialized
INFO - 2025-03-06 10:34:31 --> URI Class Initialized
INFO - 2025-03-06 10:34:31 --> Router Class Initialized
INFO - 2025-03-06 10:34:31 --> Output Class Initialized
INFO - 2025-03-06 10:34:31 --> Security Class Initialized
DEBUG - 2025-03-06 10:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:34:31 --> Input Class Initialized
INFO - 2025-03-06 10:34:31 --> Language Class Initialized
INFO - 2025-03-06 10:34:31 --> Loader Class Initialized
INFO - 2025-03-06 10:34:31 --> Helper loaded: url_helper
INFO - 2025-03-06 10:34:31 --> Helper loaded: file_helper
INFO - 2025-03-06 10:34:31 --> Controller Class Initialized
INFO - 2025-03-06 10:34:31 --> Upload Class Initialized
INFO - 2025-03-06 10:34:31 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:34:31 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\ci3\application\views\student.php 43
INFO - 2025-03-06 10:34:45 --> Config Class Initialized
INFO - 2025-03-06 10:34:45 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:34:45 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:34:45 --> Utf8 Class Initialized
INFO - 2025-03-06 10:34:45 --> URI Class Initialized
INFO - 2025-03-06 10:34:45 --> Router Class Initialized
INFO - 2025-03-06 10:34:45 --> Output Class Initialized
INFO - 2025-03-06 10:34:45 --> Security Class Initialized
DEBUG - 2025-03-06 10:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:34:45 --> Input Class Initialized
INFO - 2025-03-06 10:34:45 --> Language Class Initialized
INFO - 2025-03-06 10:34:45 --> Loader Class Initialized
INFO - 2025-03-06 10:34:45 --> Helper loaded: url_helper
INFO - 2025-03-06 10:34:45 --> Helper loaded: file_helper
INFO - 2025-03-06 10:34:45 --> Controller Class Initialized
INFO - 2025-03-06 10:34:45 --> Upload Class Initialized
INFO - 2025-03-06 10:34:45 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:34:45 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\ci3\application\views\student.php 43
INFO - 2025-03-06 10:35:49 --> Config Class Initialized
INFO - 2025-03-06 10:35:49 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:35:49 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:35:49 --> Utf8 Class Initialized
INFO - 2025-03-06 10:35:49 --> URI Class Initialized
INFO - 2025-03-06 10:35:49 --> Router Class Initialized
INFO - 2025-03-06 10:35:49 --> Output Class Initialized
INFO - 2025-03-06 10:35:49 --> Security Class Initialized
DEBUG - 2025-03-06 10:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:35:49 --> Input Class Initialized
INFO - 2025-03-06 10:35:49 --> Language Class Initialized
INFO - 2025-03-06 10:35:49 --> Loader Class Initialized
INFO - 2025-03-06 10:35:49 --> Helper loaded: url_helper
INFO - 2025-03-06 10:35:49 --> Helper loaded: file_helper
INFO - 2025-03-06 10:35:49 --> Controller Class Initialized
INFO - 2025-03-06 10:35:49 --> Upload Class Initialized
INFO - 2025-03-06 10:35:49 --> Database Driver Class Initialized
INFO - 2025-03-06 10:36:18 --> Config Class Initialized
INFO - 2025-03-06 10:36:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:36:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:36:18 --> Utf8 Class Initialized
INFO - 2025-03-06 10:36:18 --> URI Class Initialized
INFO - 2025-03-06 10:36:18 --> Router Class Initialized
INFO - 2025-03-06 10:36:18 --> Output Class Initialized
INFO - 2025-03-06 10:36:18 --> Security Class Initialized
DEBUG - 2025-03-06 10:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:36:18 --> Input Class Initialized
INFO - 2025-03-06 10:36:18 --> Language Class Initialized
INFO - 2025-03-06 10:36:18 --> Loader Class Initialized
INFO - 2025-03-06 10:36:18 --> Helper loaded: url_helper
INFO - 2025-03-06 10:36:18 --> Helper loaded: file_helper
INFO - 2025-03-06 10:36:18 --> Controller Class Initialized
INFO - 2025-03-06 10:36:18 --> Upload Class Initialized
INFO - 2025-03-06 10:36:18 --> Database Driver Class Initialized
INFO - 2025-03-06 10:36:30 --> Config Class Initialized
INFO - 2025-03-06 10:36:30 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:36:30 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:36:30 --> Utf8 Class Initialized
INFO - 2025-03-06 10:36:30 --> URI Class Initialized
INFO - 2025-03-06 10:36:30 --> Router Class Initialized
INFO - 2025-03-06 10:36:30 --> Output Class Initialized
INFO - 2025-03-06 10:36:30 --> Security Class Initialized
DEBUG - 2025-03-06 10:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:36:30 --> Input Class Initialized
INFO - 2025-03-06 10:36:30 --> Language Class Initialized
INFO - 2025-03-06 10:36:30 --> Loader Class Initialized
INFO - 2025-03-06 10:36:30 --> Helper loaded: url_helper
INFO - 2025-03-06 10:36:30 --> Helper loaded: file_helper
INFO - 2025-03-06 10:36:30 --> Controller Class Initialized
INFO - 2025-03-06 10:36:30 --> Upload Class Initialized
INFO - 2025-03-06 10:36:30 --> Database Driver Class Initialized
INFO - 2025-03-06 10:37:44 --> Config Class Initialized
INFO - 2025-03-06 10:37:44 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:37:44 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:37:44 --> Utf8 Class Initialized
INFO - 2025-03-06 10:37:44 --> URI Class Initialized
INFO - 2025-03-06 10:37:44 --> Router Class Initialized
INFO - 2025-03-06 10:37:44 --> Output Class Initialized
INFO - 2025-03-06 10:37:44 --> Security Class Initialized
DEBUG - 2025-03-06 10:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:37:44 --> Input Class Initialized
INFO - 2025-03-06 10:37:44 --> Language Class Initialized
INFO - 2025-03-06 10:37:44 --> Loader Class Initialized
INFO - 2025-03-06 10:37:44 --> Helper loaded: url_helper
INFO - 2025-03-06 10:37:44 --> Helper loaded: file_helper
INFO - 2025-03-06 10:37:44 --> Controller Class Initialized
INFO - 2025-03-06 10:37:44 --> Upload Class Initialized
INFO - 2025-03-06 10:37:44 --> Database Driver Class Initialized
ERROR - 2025-03-06 10:37:44 --> Severity: Notice --> Trying to get property 'id' of non-object C:\xampp\htdocs\ci3\application\views\student.php 43
INFO - 2025-03-06 10:38:04 --> Config Class Initialized
INFO - 2025-03-06 10:38:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:38:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:38:04 --> Utf8 Class Initialized
INFO - 2025-03-06 10:38:04 --> URI Class Initialized
INFO - 2025-03-06 10:38:04 --> Router Class Initialized
INFO - 2025-03-06 10:38:04 --> Output Class Initialized
INFO - 2025-03-06 10:38:04 --> Security Class Initialized
DEBUG - 2025-03-06 10:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:38:04 --> Input Class Initialized
INFO - 2025-03-06 10:38:04 --> Language Class Initialized
INFO - 2025-03-06 10:38:04 --> Loader Class Initialized
INFO - 2025-03-06 10:38:04 --> Helper loaded: url_helper
INFO - 2025-03-06 10:38:04 --> Helper loaded: file_helper
INFO - 2025-03-06 10:38:04 --> Controller Class Initialized
INFO - 2025-03-06 10:38:04 --> Upload Class Initialized
INFO - 2025-03-06 10:38:04 --> Database Driver Class Initialized
INFO - 2025-03-06 10:38:04 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:38:04 --> Final output sent to browser
DEBUG - 2025-03-06 10:38:04 --> Total execution time: 0.0295
INFO - 2025-03-06 10:43:26 --> Config Class Initialized
INFO - 2025-03-06 10:43:26 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:43:26 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:43:26 --> Utf8 Class Initialized
INFO - 2025-03-06 10:43:26 --> URI Class Initialized
INFO - 2025-03-06 10:43:26 --> Router Class Initialized
INFO - 2025-03-06 10:43:26 --> Output Class Initialized
INFO - 2025-03-06 10:43:26 --> Security Class Initialized
DEBUG - 2025-03-06 10:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:43:26 --> Input Class Initialized
INFO - 2025-03-06 10:43:26 --> Language Class Initialized
INFO - 2025-03-06 10:43:26 --> Loader Class Initialized
INFO - 2025-03-06 10:43:26 --> Helper loaded: url_helper
INFO - 2025-03-06 10:43:26 --> Helper loaded: file_helper
INFO - 2025-03-06 10:43:26 --> Controller Class Initialized
INFO - 2025-03-06 10:43:26 --> Upload Class Initialized
INFO - 2025-03-06 10:43:26 --> Database Driver Class Initialized
INFO - 2025-03-06 10:43:26 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:43:26 --> Final output sent to browser
DEBUG - 2025-03-06 10:43:26 --> Total execution time: 0.0369
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
INFO - 2025-03-06 10:51:21 --> Loader Class Initialized
INFO - 2025-03-06 10:51:21 --> Helper loaded: url_helper
INFO - 2025-03-06 10:51:21 --> Helper loaded: file_helper
INFO - 2025-03-06 10:51:21 --> Controller Class Initialized
INFO - 2025-03-06 10:51:21 --> Upload Class Initialized
INFO - 2025-03-06 10:51:21 --> Database Driver Class Initialized
INFO - 2025-03-06 10:51:21 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:51:21 --> Final output sent to browser
DEBUG - 2025-03-06 10:51:21 --> Total execution time: 0.0374
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
ERROR - 2025-03-06 10:51:21 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
ERROR - 2025-03-06 10:51:21 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Config Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:21 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
ERROR - 2025-03-06 10:51:21 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
DEBUG - 2025-03-06 10:51:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:21 --> Utf8 Class Initialized
ERROR - 2025-03-06 10:51:21 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> URI Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
INFO - 2025-03-06 10:51:21 --> Router Class Initialized
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
INFO - 2025-03-06 10:51:21 --> Output Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
INFO - 2025-03-06 10:51:21 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
DEBUG - 2025-03-06 10:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
INFO - 2025-03-06 10:51:21 --> Input Class Initialized
INFO - 2025-03-06 10:51:21 --> Language Class Initialized
ERROR - 2025-03-06 10:51:21 --> 404 Page Not Found: 1741252140-Screenshot_2025-02-17_173532png/index
ERROR - 2025-03-06 10:51:21 --> 404 Page Not Found: 1741252077-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 10:51:24 --> Config Class Initialized
INFO - 2025-03-06 10:51:24 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:24 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:24 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:24 --> URI Class Initialized
INFO - 2025-03-06 10:51:24 --> Router Class Initialized
INFO - 2025-03-06 10:51:24 --> Output Class Initialized
INFO - 2025-03-06 10:51:24 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:24 --> Input Class Initialized
INFO - 2025-03-06 10:51:24 --> Language Class Initialized
INFO - 2025-03-06 10:51:24 --> Loader Class Initialized
INFO - 2025-03-06 10:51:24 --> Helper loaded: url_helper
INFO - 2025-03-06 10:51:24 --> Helper loaded: file_helper
INFO - 2025-03-06 10:51:24 --> Controller Class Initialized
INFO - 2025-03-06 10:51:24 --> Upload Class Initialized
INFO - 2025-03-06 10:51:24 --> Database Driver Class Initialized
INFO - 2025-03-06 10:51:24 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 10:51:24 --> Final output sent to browser
DEBUG - 2025-03-06 10:51:24 --> Total execution time: 0.0516
INFO - 2025-03-06 10:51:28 --> Config Class Initialized
INFO - 2025-03-06 10:51:28 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:28 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:28 --> URI Class Initialized
INFO - 2025-03-06 10:51:28 --> Router Class Initialized
INFO - 2025-03-06 10:51:28 --> Output Class Initialized
INFO - 2025-03-06 10:51:28 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:28 --> Input Class Initialized
INFO - 2025-03-06 10:51:28 --> Language Class Initialized
INFO - 2025-03-06 10:51:28 --> Loader Class Initialized
INFO - 2025-03-06 10:51:28 --> Helper loaded: url_helper
INFO - 2025-03-06 10:51:28 --> Helper loaded: file_helper
INFO - 2025-03-06 10:51:28 --> Controller Class Initialized
INFO - 2025-03-06 10:51:28 --> Upload Class Initialized
INFO - 2025-03-06 10:51:28 --> Database Driver Class Initialized
INFO - 2025-03-06 10:51:28 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 10:51:28 --> Final output sent to browser
DEBUG - 2025-03-06 10:51:28 --> Total execution time: 0.0300
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
INFO - 2025-03-06 10:51:52 --> Loader Class Initialized
INFO - 2025-03-06 10:51:52 --> Helper loaded: url_helper
INFO - 2025-03-06 10:51:52 --> Helper loaded: file_helper
INFO - 2025-03-06 10:51:52 --> Controller Class Initialized
INFO - 2025-03-06 10:51:52 --> Upload Class Initialized
INFO - 2025-03-06 10:51:52 --> Database Driver Class Initialized
INFO - 2025-03-06 10:51:52 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 10:51:52 --> Final output sent to browser
DEBUG - 2025-03-06 10:51:52 --> Total execution time: 0.0780
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> Config Class Initialized
INFO - 2025-03-06 10:51:52 --> Hooks Class Initialized
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
ERROR - 2025-03-06 10:51:52 --> 404 Page Not Found: 1741250931/index
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
DEBUG - 2025-03-06 10:51:52 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:52 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
INFO - 2025-03-06 10:51:52 --> URI Class Initialized
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
INFO - 2025-03-06 10:51:52 --> Router Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
INFO - 2025-03-06 10:51:52 --> Output Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
INFO - 2025-03-06 10:51:52 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 10:51:52 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
DEBUG - 2025-03-06 10:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
INFO - 2025-03-06 10:51:52 --> Input Class Initialized
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
ERROR - 2025-03-06 10:51:52 --> 404 Page Not Found: 1741252140-Screenshot_2025-02-17_173532png/index
INFO - 2025-03-06 10:51:52 --> Language Class Initialized
ERROR - 2025-03-06 10:51:52 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 10:51:52 --> 404 Page Not Found: 1741252077-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 10:51:52 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 10:51:54 --> Config Class Initialized
INFO - 2025-03-06 10:51:54 --> Hooks Class Initialized
DEBUG - 2025-03-06 10:51:54 --> UTF-8 Support Enabled
INFO - 2025-03-06 10:51:54 --> Utf8 Class Initialized
INFO - 2025-03-06 10:51:54 --> URI Class Initialized
INFO - 2025-03-06 10:51:54 --> Router Class Initialized
INFO - 2025-03-06 10:51:54 --> Output Class Initialized
INFO - 2025-03-06 10:51:54 --> Security Class Initialized
DEBUG - 2025-03-06 10:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 10:51:54 --> Input Class Initialized
INFO - 2025-03-06 10:51:54 --> Language Class Initialized
INFO - 2025-03-06 10:51:54 --> Loader Class Initialized
INFO - 2025-03-06 10:51:54 --> Helper loaded: url_helper
INFO - 2025-03-06 10:51:54 --> Helper loaded: file_helper
INFO - 2025-03-06 10:51:54 --> Controller Class Initialized
INFO - 2025-03-06 10:51:54 --> Upload Class Initialized
INFO - 2025-03-06 10:51:54 --> Database Driver Class Initialized
INFO - 2025-03-06 10:51:54 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 10:51:54 --> Final output sent to browser
DEBUG - 2025-03-06 10:51:54 --> Total execution time: 0.0325
INFO - 2025-03-06 11:00:33 --> Config Class Initialized
INFO - 2025-03-06 11:00:33 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:00:33 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:00:33 --> Utf8 Class Initialized
INFO - 2025-03-06 11:00:33 --> URI Class Initialized
INFO - 2025-03-06 11:00:33 --> Router Class Initialized
INFO - 2025-03-06 11:00:33 --> Output Class Initialized
INFO - 2025-03-06 11:00:33 --> Security Class Initialized
DEBUG - 2025-03-06 11:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:00:33 --> Input Class Initialized
INFO - 2025-03-06 11:00:33 --> Language Class Initialized
INFO - 2025-03-06 11:00:33 --> Loader Class Initialized
INFO - 2025-03-06 11:00:33 --> Helper loaded: url_helper
INFO - 2025-03-06 11:00:33 --> Helper loaded: file_helper
INFO - 2025-03-06 11:00:33 --> Controller Class Initialized
INFO - 2025-03-06 11:00:33 --> Upload Class Initialized
INFO - 2025-03-06 11:00:33 --> Database Driver Class Initialized
INFO - 2025-03-06 11:00:33 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 11:00:33 --> Final output sent to browser
DEBUG - 2025-03-06 11:00:33 --> Total execution time: 0.0424
INFO - 2025-03-06 11:00:37 --> Config Class Initialized
INFO - 2025-03-06 11:00:37 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:00:37 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:00:37 --> Utf8 Class Initialized
INFO - 2025-03-06 11:00:37 --> URI Class Initialized
INFO - 2025-03-06 11:00:37 --> Router Class Initialized
INFO - 2025-03-06 11:00:37 --> Output Class Initialized
INFO - 2025-03-06 11:00:37 --> Security Class Initialized
DEBUG - 2025-03-06 11:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:00:37 --> Input Class Initialized
INFO - 2025-03-06 11:00:37 --> Language Class Initialized
INFO - 2025-03-06 11:00:37 --> Loader Class Initialized
INFO - 2025-03-06 11:00:37 --> Helper loaded: url_helper
INFO - 2025-03-06 11:00:37 --> Helper loaded: file_helper
INFO - 2025-03-06 11:00:37 --> Controller Class Initialized
INFO - 2025-03-06 11:00:37 --> Upload Class Initialized
INFO - 2025-03-06 11:00:37 --> Database Driver Class Initialized
INFO - 2025-03-06 11:00:37 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 11:00:37 --> Final output sent to browser
DEBUG - 2025-03-06 11:00:37 --> Total execution time: 0.0560
INFO - 2025-03-06 11:00:42 --> Config Class Initialized
INFO - 2025-03-06 11:00:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:00:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:00:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:00:42 --> URI Class Initialized
INFO - 2025-03-06 11:00:42 --> Router Class Initialized
INFO - 2025-03-06 11:00:42 --> Output Class Initialized
INFO - 2025-03-06 11:00:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:00:42 --> Input Class Initialized
INFO - 2025-03-06 11:00:42 --> Language Class Initialized
INFO - 2025-03-06 11:00:42 --> Loader Class Initialized
INFO - 2025-03-06 11:00:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:00:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:00:42 --> Controller Class Initialized
INFO - 2025-03-06 11:00:42 --> Upload Class Initialized
INFO - 2025-03-06 11:00:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:00:42 --> Final output sent to browser
DEBUG - 2025-03-06 11:00:42 --> Total execution time: 0.0297
INFO - 2025-03-06 11:01:05 --> Config Class Initialized
INFO - 2025-03-06 11:01:05 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:05 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:05 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:05 --> URI Class Initialized
INFO - 2025-03-06 11:01:05 --> Router Class Initialized
INFO - 2025-03-06 11:01:05 --> Output Class Initialized
INFO - 2025-03-06 11:01:05 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:05 --> Input Class Initialized
INFO - 2025-03-06 11:01:05 --> Language Class Initialized
INFO - 2025-03-06 11:01:05 --> Loader Class Initialized
INFO - 2025-03-06 11:01:05 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:05 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:05 --> Controller Class Initialized
INFO - 2025-03-06 11:01:05 --> Upload Class Initialized
INFO - 2025-03-06 11:01:05 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:05 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 11:01:05 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:05 --> Total execution time: 0.0343
INFO - 2025-03-06 11:01:37 --> Config Class Initialized
INFO - 2025-03-06 11:01:37 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:37 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:37 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:37 --> URI Class Initialized
INFO - 2025-03-06 11:01:37 --> Router Class Initialized
INFO - 2025-03-06 11:01:37 --> Output Class Initialized
INFO - 2025-03-06 11:01:37 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:37 --> Input Class Initialized
INFO - 2025-03-06 11:01:37 --> Language Class Initialized
INFO - 2025-03-06 11:01:37 --> Loader Class Initialized
INFO - 2025-03-06 11:01:37 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:37 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:37 --> Controller Class Initialized
INFO - 2025-03-06 11:01:37 --> Upload Class Initialized
INFO - 2025-03-06 11:01:37 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:37 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 11:01:37 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:37 --> Total execution time: 0.0417
INFO - 2025-03-06 11:01:41 --> Config Class Initialized
INFO - 2025-03-06 11:01:41 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:41 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:41 --> URI Class Initialized
INFO - 2025-03-06 11:01:41 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
INFO - 2025-03-06 11:01:42 --> Loader Class Initialized
INFO - 2025-03-06 11:01:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:42 --> Controller Class Initialized
INFO - 2025-03-06 11:01:42 --> Upload Class Initialized
INFO - 2025-03-06 11:01:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
INFO - 2025-03-06 11:01:42 --> Loader Class Initialized
INFO - 2025-03-06 11:01:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:42 --> Controller Class Initialized
INFO - 2025-03-06 11:01:42 --> Upload Class Initialized
INFO - 2025-03-06 11:01:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:42 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:01:42 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:42 --> Total execution time: 0.0403
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:42 --> Config Class Initialized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
INFO - 2025-03-06 11:01:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
ERROR - 2025-03-06 11:01:42 --> 404 Page Not Found: 1741250948/index
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:01:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:42 --> Utf8 Class Initialized
ERROR - 2025-03-06 11:01:42 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
INFO - 2025-03-06 11:01:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:01:42 --> No URI present. Default controller set.
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Router Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
INFO - 2025-03-06 11:01:42 --> Output Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:42 --> Security Class Initialized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
INFO - 2025-03-06 11:01:42 --> Input Class Initialized
ERROR - 2025-03-06 11:01:42 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
INFO - 2025-03-06 11:01:42 --> Language Class Initialized
ERROR - 2025-03-06 11:01:42 --> 404 Page Not Found: 1741252077-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:01:42 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:01:42 --> Loader Class Initialized
INFO - 2025-03-06 11:01:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:42 --> Controller Class Initialized
INFO - 2025-03-06 11:01:42 --> Upload Class Initialized
INFO - 2025-03-06 11:01:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:42 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:01:42 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:42 --> Total execution time: 0.0491
INFO - 2025-03-06 11:01:46 --> Config Class Initialized
INFO - 2025-03-06 11:01:46 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:46 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:46 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:46 --> URI Class Initialized
INFO - 2025-03-06 11:01:46 --> Router Class Initialized
INFO - 2025-03-06 11:01:46 --> Output Class Initialized
INFO - 2025-03-06 11:01:46 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:46 --> Input Class Initialized
INFO - 2025-03-06 11:01:46 --> Language Class Initialized
INFO - 2025-03-06 11:01:46 --> Loader Class Initialized
INFO - 2025-03-06 11:01:46 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:46 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:46 --> Controller Class Initialized
INFO - 2025-03-06 11:01:46 --> Upload Class Initialized
INFO - 2025-03-06 11:01:46 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:46 --> File loaded: C:\xampp\htdocs\ci3\application\views\studentedit.php
INFO - 2025-03-06 11:01:46 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:46 --> Total execution time: 0.0427
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
INFO - 2025-03-06 11:01:50 --> Loader Class Initialized
INFO - 2025-03-06 11:01:50 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:50 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:50 --> Controller Class Initialized
INFO - 2025-03-06 11:01:50 --> Upload Class Initialized
INFO - 2025-03-06 11:01:50 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
INFO - 2025-03-06 11:01:50 --> Loader Class Initialized
INFO - 2025-03-06 11:01:50 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:50 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:50 --> Controller Class Initialized
INFO - 2025-03-06 11:01:50 --> Upload Class Initialized
INFO - 2025-03-06 11:01:50 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:50 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:01:50 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:50 --> Total execution time: 0.0383
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Config Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:50 --> Hooks Class Initialized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:01:50 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:01:50 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
INFO - 2025-03-06 11:01:50 --> URI Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
DEBUG - 2025-03-06 11:01:50 --> No URI present. Default controller set.
INFO - 2025-03-06 11:01:50 --> Router Class Initialized
ERROR - 2025-03-06 11:01:50 --> 404 Page Not Found: 1741250931/index
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> Output Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
ERROR - 2025-03-06 11:01:50 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:01:50 --> Security Class Initialized
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
DEBUG - 2025-03-06 11:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:01:50 --> Input Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
INFO - 2025-03-06 11:01:50 --> Language Class Initialized
ERROR - 2025-03-06 11:01:50 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:01:50 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:01:50 --> Loader Class Initialized
INFO - 2025-03-06 11:01:50 --> Helper loaded: url_helper
INFO - 2025-03-06 11:01:50 --> Helper loaded: file_helper
INFO - 2025-03-06 11:01:50 --> Controller Class Initialized
INFO - 2025-03-06 11:01:50 --> Upload Class Initialized
INFO - 2025-03-06 11:01:50 --> Database Driver Class Initialized
INFO - 2025-03-06 11:01:50 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:01:50 --> Final output sent to browser
DEBUG - 2025-03-06 11:01:50 --> Total execution time: 0.0474
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
INFO - 2025-03-06 11:12:04 --> Loader Class Initialized
INFO - 2025-03-06 11:12:04 --> Helper loaded: url_helper
INFO - 2025-03-06 11:12:04 --> Helper loaded: file_helper
INFO - 2025-03-06 11:12:04 --> Controller Class Initialized
INFO - 2025-03-06 11:12:04 --> Upload Class Initialized
INFO - 2025-03-06 11:12:04 --> Database Driver Class Initialized
INFO - 2025-03-06 11:12:04 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:12:04 --> Final output sent to browser
DEBUG - 2025-03-06 11:12:04 --> Total execution time: 0.0452
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
ERROR - 2025-03-06 11:12:04 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
ERROR - 2025-03-06 11:12:04 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
ERROR - 2025-03-06 11:12:04 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
ERROR - 2025-03-06 11:12:04 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
DEBUG - 2025-03-06 11:12:04 --> No URI present. Default controller set.
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
INFO - 2025-03-06 11:12:04 --> Loader Class Initialized
INFO - 2025-03-06 11:12:04 --> Helper loaded: url_helper
INFO - 2025-03-06 11:12:04 --> Helper loaded: file_helper
INFO - 2025-03-06 11:12:04 --> Controller Class Initialized
INFO - 2025-03-06 11:12:04 --> Upload Class Initialized
INFO - 2025-03-06 11:12:04 --> Database Driver Class Initialized
INFO - 2025-03-06 11:12:04 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:12:04 --> Final output sent to browser
DEBUG - 2025-03-06 11:12:04 --> Total execution time: 0.0536
INFO - 2025-03-06 11:12:04 --> Config Class Initialized
INFO - 2025-03-06 11:12:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:04 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:04 --> URI Class Initialized
DEBUG - 2025-03-06 11:12:04 --> No URI present. Default controller set.
INFO - 2025-03-06 11:12:04 --> Router Class Initialized
INFO - 2025-03-06 11:12:04 --> Output Class Initialized
INFO - 2025-03-06 11:12:04 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:04 --> Input Class Initialized
INFO - 2025-03-06 11:12:04 --> Language Class Initialized
INFO - 2025-03-06 11:12:04 --> Loader Class Initialized
INFO - 2025-03-06 11:12:04 --> Helper loaded: url_helper
INFO - 2025-03-06 11:12:04 --> Helper loaded: file_helper
INFO - 2025-03-06 11:12:04 --> Controller Class Initialized
INFO - 2025-03-06 11:12:04 --> Upload Class Initialized
INFO - 2025-03-06 11:12:04 --> Database Driver Class Initialized
INFO - 2025-03-06 11:12:04 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:12:04 --> Final output sent to browser
DEBUG - 2025-03-06 11:12:04 --> Total execution time: 0.0491
INFO - 2025-03-06 11:12:21 --> Config Class Initialized
INFO - 2025-03-06 11:12:21 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:21 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:21 --> URI Class Initialized
INFO - 2025-03-06 11:12:21 --> Router Class Initialized
INFO - 2025-03-06 11:12:21 --> Output Class Initialized
INFO - 2025-03-06 11:12:21 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:21 --> Input Class Initialized
INFO - 2025-03-06 11:12:21 --> Language Class Initialized
INFO - 2025-03-06 11:12:21 --> Loader Class Initialized
INFO - 2025-03-06 11:12:21 --> Helper loaded: url_helper
INFO - 2025-03-06 11:12:21 --> Helper loaded: file_helper
INFO - 2025-03-06 11:12:21 --> Controller Class Initialized
INFO - 2025-03-06 11:12:21 --> Upload Class Initialized
INFO - 2025-03-06 11:12:21 --> Database Driver Class Initialized
INFO - 2025-03-06 11:12:21 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:12:21 --> Final output sent to browser
DEBUG - 2025-03-06 11:12:21 --> Total execution time: 0.0515
INFO - 2025-03-06 11:12:21 --> Config Class Initialized
INFO - 2025-03-06 11:12:21 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:21 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:21 --> URI Class Initialized
INFO - 2025-03-06 11:12:21 --> Router Class Initialized
INFO - 2025-03-06 11:12:21 --> Config Class Initialized
INFO - 2025-03-06 11:12:21 --> Hooks Class Initialized
INFO - 2025-03-06 11:12:21 --> Output Class Initialized
INFO - 2025-03-06 11:12:21 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:21 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:21 --> Input Class Initialized
INFO - 2025-03-06 11:12:21 --> Language Class Initialized
INFO - 2025-03-06 11:12:21 --> URI Class Initialized
ERROR - 2025-03-06 11:12:21 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:12:21 --> Router Class Initialized
INFO - 2025-03-06 11:12:21 --> Output Class Initialized
INFO - 2025-03-06 11:12:21 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:21 --> Input Class Initialized
INFO - 2025-03-06 11:12:21 --> Language Class Initialized
ERROR - 2025-03-06 11:12:21 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:12:21 --> Config Class Initialized
INFO - 2025-03-06 11:12:21 --> Config Class Initialized
INFO - 2025-03-06 11:12:21 --> Hooks Class Initialized
INFO - 2025-03-06 11:12:21 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:12:21 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:21 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:21 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:21 --> URI Class Initialized
INFO - 2025-03-06 11:12:21 --> URI Class Initialized
INFO - 2025-03-06 11:12:21 --> Router Class Initialized
INFO - 2025-03-06 11:12:21 --> Router Class Initialized
INFO - 2025-03-06 11:12:21 --> Output Class Initialized
INFO - 2025-03-06 11:12:21 --> Output Class Initialized
INFO - 2025-03-06 11:12:21 --> Security Class Initialized
INFO - 2025-03-06 11:12:21 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:21 --> Input Class Initialized
DEBUG - 2025-03-06 11:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:21 --> Language Class Initialized
INFO - 2025-03-06 11:12:21 --> Input Class Initialized
ERROR - 2025-03-06 11:12:21 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:12:21 --> Language Class Initialized
ERROR - 2025-03-06 11:12:21 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:12:22 --> Config Class Initialized
INFO - 2025-03-06 11:12:22 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:22 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:22 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:22 --> URI Class Initialized
DEBUG - 2025-03-06 11:12:22 --> No URI present. Default controller set.
INFO - 2025-03-06 11:12:22 --> Router Class Initialized
INFO - 2025-03-06 11:12:22 --> Output Class Initialized
INFO - 2025-03-06 11:12:22 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:22 --> Input Class Initialized
INFO - 2025-03-06 11:12:22 --> Language Class Initialized
INFO - 2025-03-06 11:12:22 --> Loader Class Initialized
INFO - 2025-03-06 11:12:22 --> Helper loaded: url_helper
INFO - 2025-03-06 11:12:22 --> Helper loaded: file_helper
INFO - 2025-03-06 11:12:22 --> Controller Class Initialized
INFO - 2025-03-06 11:12:22 --> Upload Class Initialized
INFO - 2025-03-06 11:12:22 --> Database Driver Class Initialized
INFO - 2025-03-06 11:12:22 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:12:22 --> Final output sent to browser
DEBUG - 2025-03-06 11:12:22 --> Total execution time: 0.0283
INFO - 2025-03-06 11:12:51 --> Config Class Initialized
INFO - 2025-03-06 11:12:51 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:12:51 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:12:51 --> Utf8 Class Initialized
INFO - 2025-03-06 11:12:51 --> URI Class Initialized
INFO - 2025-03-06 11:12:51 --> Router Class Initialized
INFO - 2025-03-06 11:12:51 --> Output Class Initialized
INFO - 2025-03-06 11:12:51 --> Security Class Initialized
DEBUG - 2025-03-06 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:12:51 --> Input Class Initialized
INFO - 2025-03-06 11:12:51 --> Language Class Initialized
INFO - 2025-03-06 11:12:51 --> Loader Class Initialized
INFO - 2025-03-06 11:12:51 --> Helper loaded: url_helper
INFO - 2025-03-06 11:12:51 --> Helper loaded: file_helper
INFO - 2025-03-06 11:12:51 --> Controller Class Initialized
INFO - 2025-03-06 11:12:51 --> Upload Class Initialized
INFO - 2025-03-06 11:12:51 --> Database Driver Class Initialized
INFO - 2025-03-06 11:14:58 --> Config Class Initialized
INFO - 2025-03-06 11:14:58 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:14:58 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:14:58 --> Utf8 Class Initialized
INFO - 2025-03-06 11:14:58 --> URI Class Initialized
INFO - 2025-03-06 11:14:58 --> Router Class Initialized
INFO - 2025-03-06 11:14:58 --> Output Class Initialized
INFO - 2025-03-06 11:14:58 --> Security Class Initialized
DEBUG - 2025-03-06 11:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:14:58 --> Input Class Initialized
INFO - 2025-03-06 11:14:58 --> Language Class Initialized
INFO - 2025-03-06 11:14:58 --> Loader Class Initialized
INFO - 2025-03-06 11:14:58 --> Helper loaded: url_helper
INFO - 2025-03-06 11:14:58 --> Helper loaded: file_helper
INFO - 2025-03-06 11:14:58 --> Controller Class Initialized
INFO - 2025-03-06 11:14:58 --> Upload Class Initialized
INFO - 2025-03-06 11:14:58 --> Database Driver Class Initialized
INFO - 2025-03-06 11:15:00 --> Config Class Initialized
INFO - 2025-03-06 11:15:00 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:15:00 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:00 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:00 --> URI Class Initialized
INFO - 2025-03-06 11:15:00 --> Router Class Initialized
INFO - 2025-03-06 11:15:00 --> Output Class Initialized
INFO - 2025-03-06 11:15:00 --> Security Class Initialized
DEBUG - 2025-03-06 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:00 --> Input Class Initialized
INFO - 2025-03-06 11:15:00 --> Language Class Initialized
INFO - 2025-03-06 11:15:00 --> Loader Class Initialized
INFO - 2025-03-06 11:15:00 --> Helper loaded: url_helper
INFO - 2025-03-06 11:15:00 --> Helper loaded: file_helper
INFO - 2025-03-06 11:15:00 --> Controller Class Initialized
INFO - 2025-03-06 11:15:00 --> Upload Class Initialized
INFO - 2025-03-06 11:15:00 --> Database Driver Class Initialized
INFO - 2025-03-06 11:15:00 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:15:00 --> Final output sent to browser
DEBUG - 2025-03-06 11:15:00 --> Total execution time: 0.0584
INFO - 2025-03-06 11:15:00 --> Config Class Initialized
INFO - 2025-03-06 11:15:00 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:15:00 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:00 --> Config Class Initialized
INFO - 2025-03-06 11:15:00 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:00 --> Hooks Class Initialized
INFO - 2025-03-06 11:15:00 --> URI Class Initialized
INFO - 2025-03-06 11:15:00 --> Router Class Initialized
DEBUG - 2025-03-06 11:15:00 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:00 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:00 --> Output Class Initialized
INFO - 2025-03-06 11:15:00 --> URI Class Initialized
INFO - 2025-03-06 11:15:00 --> Router Class Initialized
INFO - 2025-03-06 11:15:00 --> Security Class Initialized
DEBUG - 2025-03-06 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:00 --> Input Class Initialized
INFO - 2025-03-06 11:15:00 --> Output Class Initialized
INFO - 2025-03-06 11:15:00 --> Language Class Initialized
INFO - 2025-03-06 11:15:00 --> Security Class Initialized
ERROR - 2025-03-06 11:15:00 --> 404 Page Not Found: 1741250931/index
DEBUG - 2025-03-06 11:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:00 --> Input Class Initialized
INFO - 2025-03-06 11:15:00 --> Language Class Initialized
ERROR - 2025-03-06 11:15:00 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:15:01 --> Config Class Initialized
INFO - 2025-03-06 11:15:01 --> Config Class Initialized
INFO - 2025-03-06 11:15:01 --> Hooks Class Initialized
INFO - 2025-03-06 11:15:01 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:15:01 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:01 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:15:01 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:01 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:01 --> URI Class Initialized
INFO - 2025-03-06 11:15:01 --> URI Class Initialized
INFO - 2025-03-06 11:15:01 --> Router Class Initialized
INFO - 2025-03-06 11:15:01 --> Output Class Initialized
INFO - 2025-03-06 11:15:01 --> Router Class Initialized
INFO - 2025-03-06 11:15:01 --> Security Class Initialized
INFO - 2025-03-06 11:15:01 --> Output Class Initialized
DEBUG - 2025-03-06 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:01 --> Input Class Initialized
INFO - 2025-03-06 11:15:01 --> Security Class Initialized
INFO - 2025-03-06 11:15:01 --> Language Class Initialized
DEBUG - 2025-03-06 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:01 --> Input Class Initialized
INFO - 2025-03-06 11:15:01 --> Language Class Initialized
ERROR - 2025-03-06 11:15:01 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:15:01 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:15:01 --> Config Class Initialized
INFO - 2025-03-06 11:15:01 --> Hooks Class Initialized
INFO - 2025-03-06 11:15:01 --> Config Class Initialized
INFO - 2025-03-06 11:15:01 --> Config Class Initialized
INFO - 2025-03-06 11:15:01 --> Hooks Class Initialized
INFO - 2025-03-06 11:15:01 --> Config Class Initialized
INFO - 2025-03-06 11:15:01 --> Hooks Class Initialized
INFO - 2025-03-06 11:15:01 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:15:01 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:01 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:15:01 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:01 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:15:01 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:01 --> URI Class Initialized
INFO - 2025-03-06 11:15:01 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:01 --> URI Class Initialized
INFO - 2025-03-06 11:15:01 --> URI Class Initialized
INFO - 2025-03-06 11:15:01 --> Router Class Initialized
DEBUG - 2025-03-06 11:15:01 --> No URI present. Default controller set.
INFO - 2025-03-06 11:15:01 --> Router Class Initialized
INFO - 2025-03-06 11:15:01 --> Output Class Initialized
INFO - 2025-03-06 11:15:01 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:01 --> Router Class Initialized
INFO - 2025-03-06 11:15:01 --> URI Class Initialized
INFO - 2025-03-06 11:15:01 --> Output Class Initialized
INFO - 2025-03-06 11:15:01 --> Security Class Initialized
INFO - 2025-03-06 11:15:01 --> Output Class Initialized
INFO - 2025-03-06 11:15:01 --> Security Class Initialized
DEBUG - 2025-03-06 11:15:01 --> No URI present. Default controller set.
INFO - 2025-03-06 11:15:01 --> Router Class Initialized
DEBUG - 2025-03-06 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:01 --> Security Class Initialized
DEBUG - 2025-03-06 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:01 --> Input Class Initialized
INFO - 2025-03-06 11:15:01 --> Input Class Initialized
DEBUG - 2025-03-06 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:01 --> Language Class Initialized
INFO - 2025-03-06 11:15:01 --> Output Class Initialized
INFO - 2025-03-06 11:15:01 --> Input Class Initialized
INFO - 2025-03-06 11:15:01 --> Language Class Initialized
INFO - 2025-03-06 11:15:01 --> Language Class Initialized
INFO - 2025-03-06 11:15:01 --> Security Class Initialized
ERROR - 2025-03-06 11:15:01 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:15:01 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:15:01 --> Loader Class Initialized
DEBUG - 2025-03-06 11:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:01 --> Input Class Initialized
INFO - 2025-03-06 11:15:01 --> Language Class Initialized
INFO - 2025-03-06 11:15:01 --> Helper loaded: url_helper
INFO - 2025-03-06 11:15:01 --> Helper loaded: file_helper
INFO - 2025-03-06 11:15:01 --> Controller Class Initialized
INFO - 2025-03-06 11:15:01 --> Loader Class Initialized
INFO - 2025-03-06 11:15:01 --> Helper loaded: url_helper
INFO - 2025-03-06 11:15:01 --> Upload Class Initialized
INFO - 2025-03-06 11:15:01 --> Helper loaded: file_helper
INFO - 2025-03-06 11:15:01 --> Controller Class Initialized
INFO - 2025-03-06 11:15:01 --> Upload Class Initialized
INFO - 2025-03-06 11:15:01 --> Database Driver Class Initialized
INFO - 2025-03-06 11:15:01 --> Database Driver Class Initialized
INFO - 2025-03-06 11:15:01 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:15:01 --> Final output sent to browser
DEBUG - 2025-03-06 11:15:01 --> Total execution time: 0.0590
INFO - 2025-03-06 11:15:01 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:15:01 --> Final output sent to browser
DEBUG - 2025-03-06 11:15:01 --> Total execution time: 0.0820
INFO - 2025-03-06 11:15:09 --> Config Class Initialized
INFO - 2025-03-06 11:15:09 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:15:09 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:09 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:09 --> URI Class Initialized
INFO - 2025-03-06 11:15:09 --> Router Class Initialized
INFO - 2025-03-06 11:15:09 --> Output Class Initialized
INFO - 2025-03-06 11:15:09 --> Security Class Initialized
DEBUG - 2025-03-06 11:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:09 --> Input Class Initialized
INFO - 2025-03-06 11:15:09 --> Language Class Initialized
INFO - 2025-03-06 11:15:09 --> Loader Class Initialized
INFO - 2025-03-06 11:15:09 --> Helper loaded: url_helper
INFO - 2025-03-06 11:15:09 --> Helper loaded: file_helper
INFO - 2025-03-06 11:15:09 --> Controller Class Initialized
INFO - 2025-03-06 11:15:09 --> Upload Class Initialized
INFO - 2025-03-06 11:15:09 --> Database Driver Class Initialized
INFO - 2025-03-06 11:15:17 --> Config Class Initialized
INFO - 2025-03-06 11:15:17 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:15:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:15:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:15:17 --> URI Class Initialized
INFO - 2025-03-06 11:15:17 --> Router Class Initialized
INFO - 2025-03-06 11:15:17 --> Output Class Initialized
INFO - 2025-03-06 11:15:17 --> Security Class Initialized
DEBUG - 2025-03-06 11:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:15:17 --> Input Class Initialized
INFO - 2025-03-06 11:15:17 --> Language Class Initialized
INFO - 2025-03-06 11:15:17 --> Loader Class Initialized
INFO - 2025-03-06 11:15:17 --> Helper loaded: url_helper
INFO - 2025-03-06 11:15:17 --> Helper loaded: file_helper
INFO - 2025-03-06 11:15:17 --> Controller Class Initialized
INFO - 2025-03-06 11:15:17 --> Upload Class Initialized
INFO - 2025-03-06 11:15:17 --> Database Driver Class Initialized
INFO - 2025-03-06 11:18:18 --> Config Class Initialized
INFO - 2025-03-06 11:18:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:18:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:18 --> URI Class Initialized
INFO - 2025-03-06 11:18:18 --> Router Class Initialized
INFO - 2025-03-06 11:18:18 --> Output Class Initialized
INFO - 2025-03-06 11:18:18 --> Security Class Initialized
DEBUG - 2025-03-06 11:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:18 --> Input Class Initialized
INFO - 2025-03-06 11:18:18 --> Language Class Initialized
INFO - 2025-03-06 11:18:18 --> Loader Class Initialized
INFO - 2025-03-06 11:18:18 --> Helper loaded: url_helper
INFO - 2025-03-06 11:18:18 --> Helper loaded: file_helper
INFO - 2025-03-06 11:18:18 --> Controller Class Initialized
INFO - 2025-03-06 11:18:18 --> Upload Class Initialized
INFO - 2025-03-06 11:18:18 --> Database Driver Class Initialized
INFO - 2025-03-06 11:18:18 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:18:18 --> Final output sent to browser
DEBUG - 2025-03-06 11:18:18 --> Total execution time: 0.0477
INFO - 2025-03-06 11:18:18 --> Config Class Initialized
INFO - 2025-03-06 11:18:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:18 --> Config Class Initialized
INFO - 2025-03-06 11:18:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:18:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:18 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:18:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:18 --> URI Class Initialized
INFO - 2025-03-06 11:18:18 --> URI Class Initialized
INFO - 2025-03-06 11:18:18 --> Router Class Initialized
INFO - 2025-03-06 11:18:18 --> Router Class Initialized
INFO - 2025-03-06 11:18:18 --> Output Class Initialized
INFO - 2025-03-06 11:18:18 --> Output Class Initialized
INFO - 2025-03-06 11:18:18 --> Security Class Initialized
INFO - 2025-03-06 11:18:18 --> Security Class Initialized
DEBUG - 2025-03-06 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:18 --> Input Class Initialized
INFO - 2025-03-06 11:18:18 --> Input Class Initialized
INFO - 2025-03-06 11:18:18 --> Language Class Initialized
INFO - 2025-03-06 11:18:18 --> Language Class Initialized
ERROR - 2025-03-06 11:18:18 --> 404 Page Not Found: 1741250948/index
ERROR - 2025-03-06 11:18:18 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:18:19 --> No URI present. Default controller set.
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
INFO - 2025-03-06 11:18:19 --> Loader Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Helper loaded: url_helper
ERROR - 2025-03-06 11:18:19 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
INFO - 2025-03-06 11:18:19 --> Helper loaded: file_helper
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
ERROR - 2025-03-06 11:18:19 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:18:19 --> Controller Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
ERROR - 2025-03-06 11:18:19 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:18:19 --> Upload Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:19 --> Database Driver Class Initialized
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
INFO - 2025-03-06 11:18:19 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:18:19 --> Final output sent to browser
DEBUG - 2025-03-06 11:18:19 --> Total execution time: 0.0814
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
INFO - 2025-03-06 11:18:19 --> Loader Class Initialized
INFO - 2025-03-06 11:18:19 --> Helper loaded: url_helper
INFO - 2025-03-06 11:18:19 --> Helper loaded: file_helper
INFO - 2025-03-06 11:18:19 --> Controller Class Initialized
INFO - 2025-03-06 11:18:19 --> Upload Class Initialized
INFO - 2025-03-06 11:18:19 --> Database Driver Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
INFO - 2025-03-06 11:18:19 --> Config Class Initialized
INFO - 2025-03-06 11:18:19 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:18:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
INFO - 2025-03-06 11:18:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:18:19 --> URI Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Router Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> Output Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
INFO - 2025-03-06 11:18:19 --> Security Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
DEBUG - 2025-03-06 11:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
INFO - 2025-03-06 11:18:19 --> Input Class Initialized
INFO - 2025-03-06 11:18:19 --> Language Class Initialized
ERROR - 2025-03-06 11:18:19 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:18:19 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:18:19 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
INFO - 2025-03-06 11:20:28 --> Loader Class Initialized
INFO - 2025-03-06 11:20:28 --> Helper loaded: url_helper
INFO - 2025-03-06 11:20:28 --> Helper loaded: file_helper
INFO - 2025-03-06 11:20:28 --> Controller Class Initialized
INFO - 2025-03-06 11:20:28 --> Upload Class Initialized
INFO - 2025-03-06 11:20:28 --> Database Driver Class Initialized
INFO - 2025-03-06 11:20:28 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:20:28 --> Final output sent to browser
DEBUG - 2025-03-06 11:20:28 --> Total execution time: 0.0477
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741250948/index
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:20:28 --> No URI present. Default controller set.
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Loader Class Initialized
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:20:28 --> Helper loaded: url_helper
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Helper loaded: file_helper
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Controller Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:20:28 --> Upload Class Initialized
INFO - 2025-03-06 11:20:28 --> Database Driver Class Initialized
INFO - 2025-03-06 11:20:28 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:20:28 --> Final output sent to browser
DEBUG - 2025-03-06 11:20:28 --> Total execution time: 0.1002
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
INFO - 2025-03-06 11:20:28 --> Config Class Initialized
INFO - 2025-03-06 11:20:28 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
DEBUG - 2025-03-06 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:20:28 --> Utf8 Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> URI Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
INFO - 2025-03-06 11:20:28 --> Router Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Output Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Security Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
DEBUG - 2025-03-06 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:20:28 --> Input Class Initialized
INFO - 2025-03-06 11:20:28 --> Loader Class Initialized
INFO - 2025-03-06 11:20:28 --> Language Class Initialized
INFO - 2025-03-06 11:20:28 --> Helper loaded: url_helper
ERROR - 2025-03-06 11:20:28 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:20:28 --> Helper loaded: file_helper
INFO - 2025-03-06 11:20:28 --> Controller Class Initialized
INFO - 2025-03-06 11:20:28 --> Upload Class Initialized
INFO - 2025-03-06 11:20:28 --> Database Driver Class Initialized
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
INFO - 2025-03-06 11:22:18 --> Loader Class Initialized
INFO - 2025-03-06 11:22:18 --> Helper loaded: url_helper
INFO - 2025-03-06 11:22:18 --> Helper loaded: file_helper
INFO - 2025-03-06 11:22:18 --> Controller Class Initialized
INFO - 2025-03-06 11:22:18 --> Upload Class Initialized
INFO - 2025-03-06 11:22:18 --> Database Driver Class Initialized
INFO - 2025-03-06 11:22:18 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:22:18 --> Final output sent to browser
DEBUG - 2025-03-06 11:22:18 --> Total execution time: 0.0361
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 11:22:18 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
ERROR - 2025-03-06 11:22:18 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
ERROR - 2025-03-06 11:22:18 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:22:18 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Config Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:22:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
DEBUG - 2025-03-06 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:22:18 --> No URI present. Default controller set.
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
INFO - 2025-03-06 11:22:18 --> URI Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Router Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Output Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Security Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
DEBUG - 2025-03-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:18 --> Input Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
INFO - 2025-03-06 11:22:18 --> Language Class Initialized
INFO - 2025-03-06 11:22:18 --> Loader Class Initialized
ERROR - 2025-03-06 11:22:19 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:22:19 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:22:19 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:22:19 --> Helper loaded: url_helper
INFO - 2025-03-06 11:22:19 --> Helper loaded: file_helper
INFO - 2025-03-06 11:22:19 --> Controller Class Initialized
INFO - 2025-03-06 11:22:19 --> Upload Class Initialized
INFO - 2025-03-06 11:22:19 --> Database Driver Class Initialized
INFO - 2025-03-06 11:22:19 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:22:19 --> Final output sent to browser
DEBUG - 2025-03-06 11:22:19 --> Total execution time: 0.0615
INFO - 2025-03-06 11:22:19 --> Config Class Initialized
INFO - 2025-03-06 11:22:19 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:22:19 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:22:19 --> Utf8 Class Initialized
INFO - 2025-03-06 11:22:19 --> URI Class Initialized
INFO - 2025-03-06 11:22:19 --> Router Class Initialized
INFO - 2025-03-06 11:22:19 --> Output Class Initialized
INFO - 2025-03-06 11:22:19 --> Security Class Initialized
DEBUG - 2025-03-06 11:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:22:19 --> Input Class Initialized
INFO - 2025-03-06 11:22:19 --> Language Class Initialized
ERROR - 2025-03-06 11:22:19 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:52:30 --> Config Class Initialized
INFO - 2025-03-06 11:52:30 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:30 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:30 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:30 --> URI Class Initialized
INFO - 2025-03-06 11:52:30 --> Router Class Initialized
INFO - 2025-03-06 11:52:30 --> Output Class Initialized
INFO - 2025-03-06 11:52:30 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:30 --> Input Class Initialized
INFO - 2025-03-06 11:52:30 --> Language Class Initialized
INFO - 2025-03-06 11:52:30 --> Loader Class Initialized
INFO - 2025-03-06 11:52:30 --> Helper loaded: url_helper
INFO - 2025-03-06 11:52:30 --> Helper loaded: file_helper
INFO - 2025-03-06 11:52:30 --> Controller Class Initialized
INFO - 2025-03-06 11:52:30 --> Upload Class Initialized
INFO - 2025-03-06 11:52:30 --> Database Driver Class Initialized
INFO - 2025-03-06 11:52:30 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:52:30 --> Final output sent to browser
DEBUG - 2025-03-06 11:52:30 --> Total execution time: 0.0445
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
DEBUG - 2025-03-06 11:52:31 --> No URI present. Default controller set.
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> Loader Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> Helper loaded: url_helper
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Helper loaded: file_helper
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Controller Class Initialized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Upload Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Database Driver Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
INFO - 2025-03-06 11:52:31 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:52:31 --> Final output sent to browser
DEBUG - 2025-03-06 11:52:31 --> Total execution time: 0.1947
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
INFO - 2025-03-06 11:52:31 --> Loader Class Initialized
INFO - 2025-03-06 11:52:31 --> Helper loaded: url_helper
INFO - 2025-03-06 11:52:31 --> Helper loaded: file_helper
INFO - 2025-03-06 11:52:31 --> Config Class Initialized
INFO - 2025-03-06 11:52:31 --> Controller Class Initialized
INFO - 2025-03-06 11:52:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:31 --> Upload Class Initialized
DEBUG - 2025-03-06 11:52:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:31 --> URI Class Initialized
INFO - 2025-03-06 11:52:31 --> Router Class Initialized
INFO - 2025-03-06 11:52:31 --> Database Driver Class Initialized
INFO - 2025-03-06 11:52:31 --> Output Class Initialized
INFO - 2025-03-06 11:52:31 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:31 --> Input Class Initialized
INFO - 2025-03-06 11:52:31 --> Language Class Initialized
ERROR - 2025-03-06 11:52:31 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
INFO - 2025-03-06 11:52:42 --> Loader Class Initialized
INFO - 2025-03-06 11:52:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:52:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:52:42 --> Controller Class Initialized
INFO - 2025-03-06 11:52:42 --> Upload Class Initialized
INFO - 2025-03-06 11:52:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:52:42 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:52:42 --> Final output sent to browser
DEBUG - 2025-03-06 11:52:42 --> Total execution time: 0.0520
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
ERROR - 2025-03-06 11:52:42 --> 404 Page Not Found: 1741250931/index
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
ERROR - 2025-03-06 11:52:42 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:52:42 --> No URI present. Default controller set.
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
INFO - 2025-03-06 11:52:42 --> URI Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
INFO - 2025-03-06 11:52:42 --> Router Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Output Class Initialized
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
INFO - 2025-03-06 11:52:42 --> Loader Class Initialized
INFO - 2025-03-06 11:52:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:52:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:52:42 --> Controller Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
INFO - 2025-03-06 11:52:42 --> Security Class Initialized
ERROR - 2025-03-06 11:52:42 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:52:42 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:52:42 --> Upload Class Initialized
DEBUG - 2025-03-06 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:42 --> Input Class Initialized
INFO - 2025-03-06 11:52:42 --> Config Class Initialized
INFO - 2025-03-06 11:52:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:42 --> Language Class Initialized
ERROR - 2025-03-06 11:52:42 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
DEBUG - 2025-03-06 11:52:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:52:43 --> URI Class Initialized
INFO - 2025-03-06 11:52:43 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:52:43 --> Router Class Initialized
INFO - 2025-03-06 11:52:43 --> Final output sent to browser
DEBUG - 2025-03-06 11:52:43 --> Total execution time: 0.1676
INFO - 2025-03-06 11:52:43 --> Output Class Initialized
INFO - 2025-03-06 11:52:43 --> Security Class Initialized
DEBUG - 2025-03-06 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:43 --> Input Class Initialized
INFO - 2025-03-06 11:52:43 --> Language Class Initialized
INFO - 2025-03-06 11:52:43 --> Config Class Initialized
INFO - 2025-03-06 11:52:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:52:43 --> Config Class Initialized
INFO - 2025-03-06 11:52:43 --> Loader Class Initialized
INFO - 2025-03-06 11:52:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:43 --> Helper loaded: url_helper
INFO - 2025-03-06 11:52:43 --> Config Class Initialized
INFO - 2025-03-06 11:52:43 --> URI Class Initialized
INFO - 2025-03-06 11:52:43 --> Helper loaded: file_helper
INFO - 2025-03-06 11:52:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:52:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:43 --> Controller Class Initialized
INFO - 2025-03-06 11:52:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:43 --> URI Class Initialized
INFO - 2025-03-06 11:52:43 --> Upload Class Initialized
INFO - 2025-03-06 11:52:43 --> Router Class Initialized
INFO - 2025-03-06 11:52:43 --> Router Class Initialized
DEBUG - 2025-03-06 11:52:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:52:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:52:43 --> URI Class Initialized
INFO - 2025-03-06 11:52:43 --> Output Class Initialized
INFO - 2025-03-06 11:52:43 --> Output Class Initialized
INFO - 2025-03-06 11:52:43 --> Router Class Initialized
INFO - 2025-03-06 11:52:43 --> Security Class Initialized
INFO - 2025-03-06 11:52:43 --> Security Class Initialized
INFO - 2025-03-06 11:52:43 --> Output Class Initialized
DEBUG - 2025-03-06 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:43 --> Input Class Initialized
INFO - 2025-03-06 11:52:43 --> Input Class Initialized
INFO - 2025-03-06 11:52:43 --> Database Driver Class Initialized
INFO - 2025-03-06 11:52:43 --> Language Class Initialized
INFO - 2025-03-06 11:52:43 --> Security Class Initialized
INFO - 2025-03-06 11:52:43 --> Language Class Initialized
ERROR - 2025-03-06 11:52:43 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
DEBUG - 2025-03-06 11:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:52:43 --> Input Class Initialized
INFO - 2025-03-06 11:52:43 --> Language Class Initialized
ERROR - 2025-03-06 11:52:43 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:52:43 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
INFO - 2025-03-06 11:53:17 --> Loader Class Initialized
INFO - 2025-03-06 11:53:17 --> Helper loaded: url_helper
INFO - 2025-03-06 11:53:17 --> Helper loaded: file_helper
INFO - 2025-03-06 11:53:17 --> Controller Class Initialized
INFO - 2025-03-06 11:53:17 --> Upload Class Initialized
INFO - 2025-03-06 11:53:17 --> Database Driver Class Initialized
INFO - 2025-03-06 11:53:17 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:53:17 --> Final output sent to browser
DEBUG - 2025-03-06 11:53:17 --> Total execution time: 0.0347
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Config Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
INFO - 2025-03-06 11:53:17 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:53:17 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> URI Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
DEBUG - 2025-03-06 11:53:17 --> No URI present. Default controller set.
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> Router Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Output Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
INFO - 2025-03-06 11:53:17 --> Security Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
DEBUG - 2025-03-06 11:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
INFO - 2025-03-06 11:53:17 --> Input Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
INFO - 2025-03-06 11:53:17 --> Language Class Initialized
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:53:17 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:53:17 --> Loader Class Initialized
INFO - 2025-03-06 11:53:17 --> Helper loaded: url_helper
INFO - 2025-03-06 11:53:17 --> Helper loaded: file_helper
INFO - 2025-03-06 11:53:17 --> Controller Class Initialized
INFO - 2025-03-06 11:53:17 --> Upload Class Initialized
INFO - 2025-03-06 11:53:17 --> Database Driver Class Initialized
INFO - 2025-03-06 11:53:17 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:53:17 --> Final output sent to browser
DEBUG - 2025-03-06 11:53:17 --> Total execution time: 0.0416
INFO - 2025-03-06 11:53:18 --> Config Class Initialized
INFO - 2025-03-06 11:53:18 --> Hooks Class Initialized
INFO - 2025-03-06 11:53:18 --> Config Class Initialized
INFO - 2025-03-06 11:53:18 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:53:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:18 --> URI Class Initialized
DEBUG - 2025-03-06 11:53:18 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:53:18 --> Utf8 Class Initialized
INFO - 2025-03-06 11:53:18 --> Router Class Initialized
INFO - 2025-03-06 11:53:18 --> URI Class Initialized
INFO - 2025-03-06 11:53:18 --> Output Class Initialized
INFO - 2025-03-06 11:53:18 --> Router Class Initialized
INFO - 2025-03-06 11:53:18 --> Security Class Initialized
INFO - 2025-03-06 11:53:18 --> Output Class Initialized
DEBUG - 2025-03-06 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:18 --> Input Class Initialized
INFO - 2025-03-06 11:53:18 --> Language Class Initialized
INFO - 2025-03-06 11:53:18 --> Security Class Initialized
ERROR - 2025-03-06 11:53:18 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
DEBUG - 2025-03-06 11:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:53:18 --> Input Class Initialized
INFO - 2025-03-06 11:53:18 --> Language Class Initialized
INFO - 2025-03-06 11:53:18 --> Loader Class Initialized
INFO - 2025-03-06 11:53:18 --> Helper loaded: url_helper
INFO - 2025-03-06 11:53:18 --> Helper loaded: file_helper
INFO - 2025-03-06 11:53:18 --> Controller Class Initialized
INFO - 2025-03-06 11:53:18 --> Upload Class Initialized
INFO - 2025-03-06 11:53:18 --> Database Driver Class Initialized
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:31 --> URI Class Initialized
INFO - 2025-03-06 11:55:31 --> Router Class Initialized
INFO - 2025-03-06 11:55:31 --> Output Class Initialized
INFO - 2025-03-06 11:55:31 --> Security Class Initialized
DEBUG - 2025-03-06 11:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:31 --> Input Class Initialized
INFO - 2025-03-06 11:55:31 --> Language Class Initialized
INFO - 2025-03-06 11:55:31 --> Loader Class Initialized
INFO - 2025-03-06 11:55:31 --> Helper loaded: url_helper
INFO - 2025-03-06 11:55:31 --> Helper loaded: file_helper
INFO - 2025-03-06 11:55:31 --> Controller Class Initialized
INFO - 2025-03-06 11:55:31 --> Upload Class Initialized
INFO - 2025-03-06 11:55:31 --> Database Driver Class Initialized
INFO - 2025-03-06 11:55:31 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:55:31 --> Final output sent to browser
DEBUG - 2025-03-06 11:55:31 --> Total execution time: 0.0458
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:31 --> URI Class Initialized
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:31 --> Router Class Initialized
INFO - 2025-03-06 11:55:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:31 --> URI Class Initialized
INFO - 2025-03-06 11:55:31 --> Output Class Initialized
INFO - 2025-03-06 11:55:31 --> Router Class Initialized
INFO - 2025-03-06 11:55:31 --> Security Class Initialized
INFO - 2025-03-06 11:55:31 --> Output Class Initialized
DEBUG - 2025-03-06 11:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:31 --> Input Class Initialized
INFO - 2025-03-06 11:55:31 --> Language Class Initialized
INFO - 2025-03-06 11:55:31 --> Security Class Initialized
ERROR - 2025-03-06 11:55:31 --> 404 Page Not Found: 1741250948/index
DEBUG - 2025-03-06 11:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:31 --> Input Class Initialized
INFO - 2025-03-06 11:55:31 --> Language Class Initialized
ERROR - 2025-03-06 11:55:31 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> URI Class Initialized
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:31 --> Router Class Initialized
INFO - 2025-03-06 11:55:31 --> Config Class Initialized
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:31 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:31 --> Output Class Initialized
DEBUG - 2025-03-06 11:55:31 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:31 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:32 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:32 --> Config Class Initialized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
INFO - 2025-03-06 11:55:32 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
DEBUG - 2025-03-06 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:55:32 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:32 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:32 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
ERROR - 2025-03-06 11:55:32 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
DEBUG - 2025-03-06 11:55:32 --> No URI present. Default controller set.
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 11:55:32 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
ERROR - 2025-03-06 11:55:32 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Loader Class Initialized
INFO - 2025-03-06 11:55:32 --> Loader Class Initialized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
INFO - 2025-03-06 11:55:32 --> Helper loaded: url_helper
INFO - 2025-03-06 11:55:32 --> Helper loaded: file_helper
INFO - 2025-03-06 11:55:32 --> Controller Class Initialized
ERROR - 2025-03-06 11:55:32 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:55:32 --> Helper loaded: url_helper
INFO - 2025-03-06 11:55:32 --> Upload Class Initialized
INFO - 2025-03-06 11:55:32 --> Helper loaded: file_helper
INFO - 2025-03-06 11:55:32 --> Controller Class Initialized
INFO - 2025-03-06 11:55:32 --> Upload Class Initialized
INFO - 2025-03-06 11:55:32 --> Database Driver Class Initialized
INFO - 2025-03-06 11:55:32 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:55:32 --> Database Driver Class Initialized
INFO - 2025-03-06 11:55:32 --> Final output sent to browser
DEBUG - 2025-03-06 11:55:32 --> Total execution time: 0.0682
INFO - 2025-03-06 11:55:32 --> Config Class Initialized
INFO - 2025-03-06 11:55:32 --> Config Class Initialized
INFO - 2025-03-06 11:55:32 --> Hooks Class Initialized
INFO - 2025-03-06 11:55:32 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:55:32 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:32 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:55:32 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:55:32 --> Utf8 Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
INFO - 2025-03-06 11:55:32 --> URI Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
INFO - 2025-03-06 11:55:32 --> Router Class Initialized
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
INFO - 2025-03-06 11:55:32 --> Output Class Initialized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Security Class Initialized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
DEBUG - 2025-03-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:55:32 --> Input Class Initialized
ERROR - 2025-03-06 11:55:32 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:55:32 --> Language Class Initialized
ERROR - 2025-03-06 11:55:32 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:22 --> Config Class Initialized
INFO - 2025-03-06 11:58:22 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:22 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:22 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:22 --> URI Class Initialized
INFO - 2025-03-06 11:58:22 --> Router Class Initialized
INFO - 2025-03-06 11:58:22 --> Output Class Initialized
INFO - 2025-03-06 11:58:22 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:22 --> Input Class Initialized
INFO - 2025-03-06 11:58:22 --> Language Class Initialized
INFO - 2025-03-06 11:58:22 --> Loader Class Initialized
INFO - 2025-03-06 11:58:23 --> Helper loaded: url_helper
INFO - 2025-03-06 11:58:23 --> Helper loaded: file_helper
INFO - 2025-03-06 11:58:23 --> Controller Class Initialized
INFO - 2025-03-06 11:58:23 --> Upload Class Initialized
INFO - 2025-03-06 11:58:23 --> Database Driver Class Initialized
INFO - 2025-03-06 11:58:23 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:58:23 --> Final output sent to browser
DEBUG - 2025-03-06 11:58:23 --> Total execution time: 0.0434
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741250931/index
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:58:23 --> No URI present. Default controller set.
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:58:23 --> Loader Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:58:23 --> Helper loaded: url_helper
INFO - 2025-03-06 11:58:23 --> Helper loaded: file_helper
INFO - 2025-03-06 11:58:23 --> Controller Class Initialized
INFO - 2025-03-06 11:58:23 --> Upload Class Initialized
INFO - 2025-03-06 11:58:23 --> Database Driver Class Initialized
INFO - 2025-03-06 11:58:23 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:58:23 --> Final output sent to browser
DEBUG - 2025-03-06 11:58:23 --> Total execution time: 0.0712
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
INFO - 2025-03-06 11:58:23 --> Loader Class Initialized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:23 --> Helper loaded: url_helper
INFO - 2025-03-06 11:58:23 --> Helper loaded: file_helper
INFO - 2025-03-06 11:58:23 --> Controller Class Initialized
INFO - 2025-03-06 11:58:23 --> Upload Class Initialized
INFO - 2025-03-06 11:58:23 --> Database Driver Class Initialized
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Config Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:23 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:58:23 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> URI Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Router Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Output Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
INFO - 2025-03-06 11:58:23 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Input Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
INFO - 2025-03-06 11:58:23 --> Language Class Initialized
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 11:58:23 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:42 --> Config Class Initialized
INFO - 2025-03-06 11:58:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:42 --> URI Class Initialized
INFO - 2025-03-06 11:58:42 --> Router Class Initialized
INFO - 2025-03-06 11:58:42 --> Output Class Initialized
INFO - 2025-03-06 11:58:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:42 --> Input Class Initialized
INFO - 2025-03-06 11:58:42 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Loader Class Initialized
INFO - 2025-03-06 11:58:43 --> Helper loaded: url_helper
INFO - 2025-03-06 11:58:43 --> Helper loaded: file_helper
INFO - 2025-03-06 11:58:43 --> Controller Class Initialized
INFO - 2025-03-06 11:58:43 --> Upload Class Initialized
INFO - 2025-03-06 11:58:43 --> Database Driver Class Initialized
INFO - 2025-03-06 11:58:43 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:58:43 --> Final output sent to browser
DEBUG - 2025-03-06 11:58:43 --> Total execution time: 0.0405
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741250931/index
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
DEBUG - 2025-03-06 11:58:43 --> No URI present. Default controller set.
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Loader Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Helper loaded: url_helper
INFO - 2025-03-06 11:58:43 --> Helper loaded: file_helper
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:58:43 --> Controller Class Initialized
INFO - 2025-03-06 11:58:43 --> Upload Class Initialized
INFO - 2025-03-06 11:58:43 --> Database Driver Class Initialized
INFO - 2025-03-06 11:58:43 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:58:43 --> Final output sent to browser
DEBUG - 2025-03-06 11:58:43 --> Total execution time: 0.0677
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Loader Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Helper loaded: url_helper
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
INFO - 2025-03-06 11:58:43 --> Helper loaded: file_helper
INFO - 2025-03-06 11:58:43 --> Controller Class Initialized
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:43 --> Upload Class Initialized
INFO - 2025-03-06 11:58:43 --> Database Driver Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Config Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
INFO - 2025-03-06 11:58:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> Utf8 Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> URI Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Router Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Output Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
INFO - 2025-03-06 11:58:43 --> Security Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
DEBUG - 2025-03-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:58:43 --> Input Class Initialized
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:58:43 --> Language Class Initialized
ERROR - 2025-03-06 11:58:43 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
INFO - 2025-03-06 11:59:42 --> Loader Class Initialized
INFO - 2025-03-06 11:59:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:59:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:59:42 --> Controller Class Initialized
INFO - 2025-03-06 11:59:42 --> Upload Class Initialized
INFO - 2025-03-06 11:59:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:59:42 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:59:42 --> Final output sent to browser
DEBUG - 2025-03-06 11:59:42 --> Total execution time: 0.0590
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
DEBUG - 2025-03-06 11:59:42 --> No URI present. Default controller set.
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Loader Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:59:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:59:42 --> Controller Class Initialized
INFO - 2025-03-06 11:59:42 --> Upload Class Initialized
INFO - 2025-03-06 11:59:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:59:42 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:59:42 --> Final output sent to browser
DEBUG - 2025-03-06 11:59:42 --> Total execution time: 0.0610
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:42 --> Config Class Initialized
INFO - 2025-03-06 11:59:42 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:42 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:42 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> URI Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
INFO - 2025-03-06 11:59:42 --> Router Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
INFO - 2025-03-06 11:59:42 --> Output Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
INFO - 2025-03-06 11:59:42 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:42 --> Input Class Initialized
INFO - 2025-03-06 11:59:42 --> Language Class Initialized
INFO - 2025-03-06 11:59:42 --> Loader Class Initialized
ERROR - 2025-03-06 11:59:42 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:42 --> Helper loaded: url_helper
INFO - 2025-03-06 11:59:42 --> Helper loaded: file_helper
INFO - 2025-03-06 11:59:42 --> Controller Class Initialized
INFO - 2025-03-06 11:59:42 --> Upload Class Initialized
INFO - 2025-03-06 11:59:42 --> Database Driver Class Initialized
INFO - 2025-03-06 11:59:56 --> Config Class Initialized
INFO - 2025-03-06 11:59:56 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:56 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:56 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:56 --> URI Class Initialized
INFO - 2025-03-06 11:59:56 --> Router Class Initialized
INFO - 2025-03-06 11:59:56 --> Output Class Initialized
INFO - 2025-03-06 11:59:56 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:56 --> Input Class Initialized
INFO - 2025-03-06 11:59:56 --> Language Class Initialized
INFO - 2025-03-06 11:59:56 --> Loader Class Initialized
INFO - 2025-03-06 11:59:56 --> Helper loaded: url_helper
INFO - 2025-03-06 11:59:56 --> Helper loaded: file_helper
INFO - 2025-03-06 11:59:56 --> Controller Class Initialized
INFO - 2025-03-06 11:59:56 --> Upload Class Initialized
INFO - 2025-03-06 11:59:56 --> Database Driver Class Initialized
INFO - 2025-03-06 11:59:56 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:59:56 --> Final output sent to browser
DEBUG - 2025-03-06 11:59:56 --> Total execution time: 0.0451
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
DEBUG - 2025-03-06 11:59:57 --> No URI present. Default controller set.
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:57 --> Loader Class Initialized
INFO - 2025-03-06 11:59:57 --> Helper loaded: url_helper
INFO - 2025-03-06 11:59:57 --> Helper loaded: file_helper
INFO - 2025-03-06 11:59:57 --> Controller Class Initialized
INFO - 2025-03-06 11:59:57 --> Upload Class Initialized
INFO - 2025-03-06 11:59:57 --> Database Driver Class Initialized
INFO - 2025-03-06 11:59:57 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 11:59:57 --> Final output sent to browser
DEBUG - 2025-03-06 11:59:57 --> Total execution time: 0.0647
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 11:59:57 --> Config Class Initialized
INFO - 2025-03-06 11:59:57 --> Hooks Class Initialized
DEBUG - 2025-03-06 11:59:57 --> UTF-8 Support Enabled
INFO - 2025-03-06 11:59:57 --> Utf8 Class Initialized
INFO - 2025-03-06 11:59:57 --> URI Class Initialized
INFO - 2025-03-06 11:59:57 --> Router Class Initialized
INFO - 2025-03-06 11:59:57 --> Output Class Initialized
INFO - 2025-03-06 11:59:57 --> Security Class Initialized
DEBUG - 2025-03-06 11:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 11:59:57 --> Input Class Initialized
INFO - 2025-03-06 11:59:57 --> Language Class Initialized
ERROR - 2025-03-06 11:59:57 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:02 --> Config Class Initialized
INFO - 2025-03-06 12:00:02 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:02 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:02 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:02 --> URI Class Initialized
INFO - 2025-03-06 12:00:02 --> Router Class Initialized
INFO - 2025-03-06 12:00:02 --> Output Class Initialized
INFO - 2025-03-06 12:00:02 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:02 --> Input Class Initialized
INFO - 2025-03-06 12:00:02 --> Language Class Initialized
INFO - 2025-03-06 12:00:02 --> Loader Class Initialized
INFO - 2025-03-06 12:00:02 --> Helper loaded: url_helper
INFO - 2025-03-06 12:00:02 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:02 --> Controller Class Initialized
INFO - 2025-03-06 12:00:02 --> Upload Class Initialized
INFO - 2025-03-06 12:00:02 --> Database Driver Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
INFO - 2025-03-06 12:00:11 --> Loader Class Initialized
INFO - 2025-03-06 12:00:11 --> Helper loaded: url_helper
INFO - 2025-03-06 12:00:11 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:11 --> Controller Class Initialized
INFO - 2025-03-06 12:00:11 --> Upload Class Initialized
INFO - 2025-03-06 12:00:11 --> Database Driver Class Initialized
INFO - 2025-03-06 12:00:11 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:00:11 --> Final output sent to browser
DEBUG - 2025-03-06 12:00:11 --> Total execution time: 0.0298
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:00:11 --> No URI present. Default controller set.
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 12:00:11 --> Loader Class Initialized
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
INFO - 2025-03-06 12:00:11 --> Helper loaded: url_helper
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:11 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:11 --> Controller Class Initialized
INFO - 2025-03-06 12:00:11 --> Upload Class Initialized
INFO - 2025-03-06 12:00:11 --> Database Driver Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:00:11 --> Final output sent to browser
DEBUG - 2025-03-06 12:00:11 --> Total execution time: 0.0998
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:11 --> Config Class Initialized
INFO - 2025-03-06 12:00:11 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:11 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:11 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:11 --> URI Class Initialized
INFO - 2025-03-06 12:00:11 --> Router Class Initialized
INFO - 2025-03-06 12:00:11 --> Output Class Initialized
INFO - 2025-03-06 12:00:11 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:11 --> Input Class Initialized
INFO - 2025-03-06 12:00:11 --> Language Class Initialized
ERROR - 2025-03-06 12:00:11 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:13 --> Config Class Initialized
INFO - 2025-03-06 12:00:13 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:13 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:13 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:13 --> URI Class Initialized
INFO - 2025-03-06 12:00:13 --> Router Class Initialized
INFO - 2025-03-06 12:00:13 --> Output Class Initialized
INFO - 2025-03-06 12:00:13 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:13 --> Input Class Initialized
INFO - 2025-03-06 12:00:13 --> Language Class Initialized
INFO - 2025-03-06 12:00:13 --> Loader Class Initialized
INFO - 2025-03-06 12:00:13 --> Helper loaded: url_helper
INFO - 2025-03-06 12:00:13 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:13 --> Controller Class Initialized
INFO - 2025-03-06 12:00:13 --> Upload Class Initialized
INFO - 2025-03-06 12:00:13 --> Database Driver Class Initialized
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
INFO - 2025-03-06 12:00:41 --> Loader Class Initialized
INFO - 2025-03-06 12:00:41 --> Helper loaded: url_helper
INFO - 2025-03-06 12:00:41 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:41 --> Controller Class Initialized
INFO - 2025-03-06 12:00:41 --> Upload Class Initialized
INFO - 2025-03-06 12:00:41 --> Database Driver Class Initialized
INFO - 2025-03-06 12:00:41 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:00:41 --> Final output sent to browser
DEBUG - 2025-03-06 12:00:41 --> Total execution time: 0.0425
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741250948/index
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
DEBUG - 2025-03-06 12:00:41 --> No URI present. Default controller set.
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:41 --> Loader Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:41 --> Helper loaded: url_helper
INFO - 2025-03-06 12:00:41 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:41 --> Controller Class Initialized
INFO - 2025-03-06 12:00:41 --> Upload Class Initialized
INFO - 2025-03-06 12:00:41 --> Database Driver Class Initialized
INFO - 2025-03-06 12:00:41 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:00:41 --> Final output sent to browser
DEBUG - 2025-03-06 12:00:41 --> Total execution time: 0.0364
INFO - 2025-03-06 12:00:41 --> Config Class Initialized
INFO - 2025-03-06 12:00:41 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:41 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:41 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:41 --> URI Class Initialized
INFO - 2025-03-06 12:00:41 --> Router Class Initialized
INFO - 2025-03-06 12:00:41 --> Output Class Initialized
INFO - 2025-03-06 12:00:41 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:41 --> Input Class Initialized
INFO - 2025-03-06 12:00:41 --> Language Class Initialized
ERROR - 2025-03-06 12:00:41 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:00:46 --> Config Class Initialized
INFO - 2025-03-06 12:00:46 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:00:46 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:00:46 --> Utf8 Class Initialized
INFO - 2025-03-06 12:00:46 --> URI Class Initialized
INFO - 2025-03-06 12:00:46 --> Router Class Initialized
INFO - 2025-03-06 12:00:46 --> Output Class Initialized
INFO - 2025-03-06 12:00:46 --> Security Class Initialized
DEBUG - 2025-03-06 12:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:00:46 --> Input Class Initialized
INFO - 2025-03-06 12:00:46 --> Language Class Initialized
INFO - 2025-03-06 12:00:46 --> Loader Class Initialized
INFO - 2025-03-06 12:00:46 --> Helper loaded: url_helper
INFO - 2025-03-06 12:00:46 --> Helper loaded: file_helper
INFO - 2025-03-06 12:00:46 --> Controller Class Initialized
INFO - 2025-03-06 12:00:46 --> Upload Class Initialized
INFO - 2025-03-06 12:00:46 --> Database Driver Class Initialized
INFO - 2025-03-06 12:02:04 --> Config Class Initialized
INFO - 2025-03-06 12:02:04 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:04 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:04 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:04 --> URI Class Initialized
INFO - 2025-03-06 12:02:04 --> Router Class Initialized
INFO - 2025-03-06 12:02:04 --> Output Class Initialized
INFO - 2025-03-06 12:02:04 --> Security Class Initialized
DEBUG - 2025-03-06 12:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:04 --> Input Class Initialized
INFO - 2025-03-06 12:02:04 --> Language Class Initialized
INFO - 2025-03-06 12:02:04 --> Loader Class Initialized
INFO - 2025-03-06 12:02:04 --> Helper loaded: url_helper
INFO - 2025-03-06 12:02:04 --> Helper loaded: file_helper
INFO - 2025-03-06 12:02:04 --> Controller Class Initialized
INFO - 2025-03-06 12:02:04 --> Upload Class Initialized
INFO - 2025-03-06 12:02:04 --> Database Driver Class Initialized
INFO - 2025-03-06 12:02:04 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:02:04 --> Final output sent to browser
DEBUG - 2025-03-06 12:02:04 --> Total execution time: 0.0495
INFO - 2025-03-06 12:02:05 --> Config Class Initialized
INFO - 2025-03-06 12:02:05 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:05 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:05 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:05 --> URI Class Initialized
INFO - 2025-03-06 12:02:05 --> Router Class Initialized
INFO - 2025-03-06 12:02:05 --> Output Class Initialized
INFO - 2025-03-06 12:02:05 --> Security Class Initialized
DEBUG - 2025-03-06 12:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:05 --> Input Class Initialized
INFO - 2025-03-06 12:02:05 --> Language Class Initialized
INFO - 2025-03-06 12:02:05 --> Loader Class Initialized
INFO - 2025-03-06 12:02:05 --> Helper loaded: url_helper
INFO - 2025-03-06 12:02:05 --> Helper loaded: file_helper
INFO - 2025-03-06 12:02:05 --> Controller Class Initialized
INFO - 2025-03-06 12:02:05 --> Upload Class Initialized
INFO - 2025-03-06 12:02:05 --> Database Driver Class Initialized
INFO - 2025-03-06 12:02:35 --> Config Class Initialized
INFO - 2025-03-06 12:02:35 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:35 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:35 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:35 --> URI Class Initialized
INFO - 2025-03-06 12:02:35 --> Router Class Initialized
INFO - 2025-03-06 12:02:35 --> Output Class Initialized
INFO - 2025-03-06 12:02:35 --> Security Class Initialized
DEBUG - 2025-03-06 12:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:35 --> Input Class Initialized
INFO - 2025-03-06 12:02:35 --> Language Class Initialized
INFO - 2025-03-06 12:02:35 --> Loader Class Initialized
INFO - 2025-03-06 12:02:35 --> Helper loaded: url_helper
INFO - 2025-03-06 12:02:35 --> Helper loaded: file_helper
INFO - 2025-03-06 12:02:35 --> Controller Class Initialized
INFO - 2025-03-06 12:02:35 --> Upload Class Initialized
INFO - 2025-03-06 12:02:35 --> Database Driver Class Initialized
INFO - 2025-03-06 12:02:35 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:02:35 --> Final output sent to browser
DEBUG - 2025-03-06 12:02:35 --> Total execution time: 0.0272
INFO - 2025-03-06 12:02:36 --> Config Class Initialized
INFO - 2025-03-06 12:02:36 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:36 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:36 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:36 --> URI Class Initialized
INFO - 2025-03-06 12:02:36 --> Router Class Initialized
INFO - 2025-03-06 12:02:36 --> Output Class Initialized
INFO - 2025-03-06 12:02:36 --> Security Class Initialized
DEBUG - 2025-03-06 12:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:36 --> Input Class Initialized
INFO - 2025-03-06 12:02:36 --> Language Class Initialized
INFO - 2025-03-06 12:02:36 --> Loader Class Initialized
INFO - 2025-03-06 12:02:36 --> Helper loaded: url_helper
INFO - 2025-03-06 12:02:36 --> Helper loaded: file_helper
INFO - 2025-03-06 12:02:36 --> Controller Class Initialized
INFO - 2025-03-06 12:02:36 --> Upload Class Initialized
INFO - 2025-03-06 12:02:36 --> Database Driver Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
DEBUG - 2025-03-06 12:02:43 --> No URI present. Default controller set.
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741250931/index
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741251975-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741251027-Screenshot_2025-02-16_010454png/index
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741250948/index
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741255971-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
INFO - 2025-03-06 12:02:43 --> Loader Class Initialized
INFO - 2025-03-06 12:02:43 --> Helper loaded: url_helper
INFO - 2025-03-06 12:02:43 --> Helper loaded: file_helper
INFO - 2025-03-06 12:02:43 --> Controller Class Initialized
INFO - 2025-03-06 12:02:43 --> Upload Class Initialized
INFO - 2025-03-06 12:02:43 --> Database Driver Class Initialized
INFO - 2025-03-06 12:02:43 --> File loaded: C:\xampp\htdocs\ci3\application\views\student.php
INFO - 2025-03-06 12:02:43 --> Final output sent to browser
DEBUG - 2025-03-06 12:02:43 --> Total execution time: 0.0687
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Config Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
INFO - 2025-03-06 12:02:43 --> Hooks Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
DEBUG - 2025-03-06 12:02:43 --> UTF-8 Support Enabled
INFO - 2025-03-06 12:02:43 --> Utf8 Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> URI Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Router Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Output Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Security Class Initialized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
DEBUG - 2025-03-06 12:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 12:02:43 --> Input Class Initialized
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741256098-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 12:02:43 --> Language Class Initialized
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741256117-Screenshot_2025-02-16_105027png/index
ERROR - 2025-03-06 12:02:43 --> 404 Page Not Found: 1741256109-Screenshot_2025-02-16_105027png/index
INFO - 2025-03-06 13:25:05 --> Config Class Initialized
INFO - 2025-03-06 13:25:05 --> Hooks Class Initialized
DEBUG - 2025-03-06 13:25:05 --> UTF-8 Support Enabled
INFO - 2025-03-06 13:25:05 --> Utf8 Class Initialized
INFO - 2025-03-06 13:25:05 --> URI Class Initialized
INFO - 2025-03-06 13:25:05 --> Router Class Initialized
INFO - 2025-03-06 13:25:05 --> Output Class Initialized
INFO - 2025-03-06 13:25:05 --> Security Class Initialized
DEBUG - 2025-03-06 13:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-03-06 13:25:05 --> Input Class Initialized
INFO - 2025-03-06 13:25:05 --> Language Class Initialized
INFO - 2025-03-06 13:25:05 --> Loader Class Initialized
INFO - 2025-03-06 13:25:05 --> Helper loaded: url_helper
INFO - 2025-03-06 13:25:05 --> Helper loaded: file_helper
INFO - 2025-03-06 13:25:05 --> Controller Class Initialized
INFO - 2025-03-06 13:25:05 --> Upload Class Initialized
INFO - 2025-03-06 13:25:05 --> Database Driver Class Initialized
INFO - 2025-03-06 13:25:05 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2025-03-06 13:25:05 --> You did not select a file to upload.
ERROR - 2025-03-06 13:25:05 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\ci3\application\controllers\Student.php 63
ERROR - 2025-03-06 13:25:05 --> Query error: Column 'file' cannot be null - Invalid query: INSERT INTO `students` (`name`, `email`, `file`) VALUES ('', '', NULL)
INFO - 2025-03-06 13:25:05 --> Language file loaded: language/english/db_lang.php
