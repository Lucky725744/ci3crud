<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

    function __construct(){
        parent::__construct();
        $this->load->library('upload');
        $this->load->database();
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{

        $data=$this->db->get('students')->result_array();
		$this->load->view('student',['student' => $data]);
	}

    function edit(){
        $id=$this->input->post('id');

        $data=$this->db->where('id',$id)->get('students')->row_array();

        $this->load->view('studentedit',['s' => $data]);

    }

    function store(){
        $name=$this->input->post('name');
        $email=$this->input->post('email');
        
        $config['upload_path']=FCPATH .'upload';
        $config['allowed_types']='jpg|png|svg|pdf';
        $config['file_name']=time() . $_FILES['file']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('file')){
            $filedata=$this->upload->data();
            $filename= $filedata['file_name'];
        }

        $data=[
            'name'=>$name,
            'email'=>$email,
            'file'=> $filename,
        ];

        $this->db->insert('students',$data);
       return redirect('Student');
    }

    function update(){
        $id=$this->input->post('id');
        $name=$this->input->post('name');
        $email=$this->input->post('email');
        
        $config['upload_path']=FCPATH .'upload';
        $config['allowed_types']='jpg|png|svg|pdf';
        $config['file_name']=time() . $_FILES['file']['name'];
        $this->upload->initialize($config);
        if($this->upload->do_upload('file')){
            $filedata=$this->upload->data();
            $filename= $filedata['file_name'];
        }else{
            $filename= $this->input->post('file');;

        }

        $data=[
            'name'=>$name,
            'email'=>$email,
            'file'=> $filename,
        ];

        $this->db->where('id',$id);
        $this->db->update('students',$data);
        //if($this->db->afftected_rows() > 0)
        if ($this->db->affected_rows() > 0) {
        
        return redirect('Student');
        }else{
            echo 'failed';
            
        }
    }

    
}
