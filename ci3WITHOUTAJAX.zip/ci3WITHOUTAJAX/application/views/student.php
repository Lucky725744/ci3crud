<html>

<head>
    <style>
        table {
            width: 100%;
        }
        
        tr,
        td,
        th {
            padding: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>

<body>
    <form method="post" action='<?php echo base_url('Student/store');?>' enctype="multipart/form-data">

     <label>Name:<input type="text" name='name'></label><br>
    <label>Email:<input type="email" name='email'></label><br>
    <label>File:<input type="file" name='file'></label><br>
    <input type='submit' value='save'>
    </form>

    <table>
        <tr>
            <td>id</td>
            <td>name</td>
            <td>email</td>
            <td>file</td>
            <td>edit</td>
        </tr>

        <tbody>
            <tr>
               <?php  foreach($student as $s) {?>
                <td><?php echo $s['id']?></td>
                <td><?php echo $s['name']?></td>
                <td><?php echo $s['email']?></td>
                <td><?php echo $s['file']?></td>
                <form method="post" action='<?php echo base_url('Student/edit');?>' enctype="multipart/form-data">
                    <input type="hidden" name='id' value='<?php echo $s['id']?>'>
                    <td><input type="submit" name='submit' value='edit'></td>
               </form>
                </tr>

            
            <?php } ?>
               
           
        </tbody>
    </table>
</body>

</html>