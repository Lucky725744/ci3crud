<html>

<head>
    <style>
        table {
            width: 100%;
        }
        
        tr,
        td,
        th {
            padding: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>

<body>
    <form method="post" action='<?php echo base_url('Student/update');?>' enctype="multipart/form-data">
    <input type="text" value='<?php echo $s['id'] ?>' name='id'>
    <label>Name:<input type="text" value='<?php echo $s['name'] ?>' name='name'></label>
    <label>Email:<input type="email" name='email' value='<?php echo $s['email'] ?>' ></label>
    <label>File:<input type="file" name='file' value='<?php echo $s['file'] ?>'></label>
    <input type='submit' value='update'>
    </form>
</body>

</html>